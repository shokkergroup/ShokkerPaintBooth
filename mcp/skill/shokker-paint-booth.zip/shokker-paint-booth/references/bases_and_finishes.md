# Bases and finishes

## Core facts
- A zone's Base is the material its surface is made of: it always supplies the spec map (M metallic, R roughness, CC clearcoat), while the separate Base Color setting decides where the visible colour comes from.
- The Foundation Bases shelf holds 20 flat sheens, from Wet Look (0/15/16) through Gloss (0/30/16) and Matte (0/200/160) to Chrome (255/2/16), that change only how light behaves and keep the car's current paint colour when picked.
- A special finish is picked into the same Base slot as a plain base but brings its own paint and its own spec as one matched pair, so it normally shows its own colours.
- The picker lists roughly 2,650 finishes in seven sections, and the search tools cover a wider catalogue of about 4,800 looks, so confirm a finish with spb_finish_details before promising it.
- To find a finish from the buyer's words, call spb_suggest_finishes first, then spb_find_finishes for exact filters, then read the best two or three with spb_finish_details.

## Contents
- How a buyer picks a base
- Base Color: where the colour comes from
- Foundation Bases: the flat ladder
- Finishes that bring their own colours versus finishes that take the zone colour
- Specials versus base + pattern + spec overlay
- Sections and shelves in the picker
- Search, filters and tag chips
- Finding finishes with the tools
- Looks and example finishes

## How a buyer picks a base
- Each zone card has a BASE section. Its first row is labelled "Base Material" and shows a tile with the current finish name; with nothing chosen the tile reads "Click to choose a base".
- Clicking the tile opens the finish picker. Picking a tile puts that finish into the zone's Base slot.
- The picker has a search box, filter buttons, sort buttons, a row of #tag chips, a "Color: AUTO" button, a "See on paint" button (previews the selected finish on the current paint file) and "✕ Close" (Esc also closes).
- Hovering "Base Material" explains the three outcomes. BOTH = the material's own paint and its spec map (the tooltip calls it the default, but a new zone with a plain base starts on SPEC ONLY, Use source paint: see Defaults below). SPEC ONLY = keep the buyer's livery and change only how it behaves (Base Color -> Use source paint). MIX = this material's spec map with colour from anywhere: another look in the library, a solid colour, or a gradient.
- Under the Base Color row the card also offers Base Scale, Base Rotation, Spec Rotation, and Base Strength (0-100%). Moving Base Scale or Base Rotation changes the material only; the colour has its own Color Scale and Color Rotation.
- Picking a different base later replaces the earlier one; the buyer's colour choice is kept or replaced according to the Base Color rules in the next section.
- Example: "make the roof chrome" -> open the roof zone's Base Material and pick Chrome from Foundation Bases. It keeps the roof's colour, which gives a chrome tinted by that colour (a dark roof goes nearly black); for silver chrome set Base Color to Use solid color with a near-white, and tell the buyer which you did.

## Base Color: where the colour comes from
- The Base Color row sits under Base Material, next to a "🔒 Lock" checkbox and a dropdown with five modes: "Use finish's own color", "Use source paint (spec only)", "Use solid color", "From special" and "Custom gradient".
- Use source paint (spec only) keeps whatever the car already has and changes only the spec. Foundation picks never touch colour: the zone keeps the source paint, and a colour the buyer chose by hand survives.
- Use solid color adds a "Color" row: a colour box, a hex field (type a hex value) and a "💉 Pick" button, a screen eyedropper that copies any colour on the car.
- From special borrows colour and artwork from another finish in the library. Use finish's own color uses the base's own palette. Custom gradient paints a gradient.
- Defaults: a zone that has a plain base but no saved colour mode renders the car's own paint (Use source paint); only a special defaults to its own colour. Picking a tile in the picker changes that: an unlocked non-Foundation base or special switches Base Color to "From special: <that tile>", so the zone takes the tile's own colours. Foundation and Foundation EFX picks keep the source paint instead, a colour the buyer chose by hand survives, and Lock Base Color stops every automatic change.
- "🔒 Lock" (Lock Base Color) keeps the zone's current colour, hue, saturation and brightness when the base is swapped, so a base can be changed purely for its spec. The picker's global button toggles between "Color: AUTO" and "Color: LOCKED" and does the same for every zone.
- A solid colour renders as the exact colour picked. The "🍬 Color Depth" slider reads "off" until it is moved; moving it switches on the candy-depth treatment together with Flip and Underglow, so leave it off for an exact match.
- Colour sliders: Hue Shift -180 to 180, Saturation -100 to 100, Brightness -100 to 200.
- Chrome and other mirror metals need a light colour. iRacing renders full metal over a dark colour nearly black, so for silver use a near-white solid, and the app warns when a dark colour sits under Chrome.
- Tools take the same choice as colour: "#rrggbb" for a solid, "source" to keep the car's paint and change only the shine, "finish" to use the finish's own colour.

## Foundation Bases: the flat ladder
- Foundation Bases is the first shelf of the picker's FOUNDATIONS section (about 25 tiles). Twenty of them are flat sheens with a constant M/R/CC and no colour of their own; the app's text lists them as (M/R/CC), and the clearcoat value 16 is the glossiest while 255 is dullest.
- Paint-side sheens, all with M 0 (R/CC): Wet Look 15/16, Gloss 30/16, Semi-Gloss 55/40, Satin 95/70, Eggshell 140/100, Matte 200/160, Primer 215/200, Flat Black 250/255. Powder Coat is 10/120/145.
- Metal-side sheens (M/R/CC): Pearl 100/40/16, Satin Pearl 100/90/60, Metallic 200/50/16, Matte Metallic 225/140/100, Candy 200/15/16, Brushed 180/75/65, Frozen 160/85/130, Bead Blast 180/160/140.
- Chrome family (M/R/CC): Chrome 255/2/16 (mirror), Dark Chrome 250/15/40 (pick a dark colour for gunmetal or black chrome), Satin Chrome 250/45/40 (broader, softer highlight).
- Because they are pure spec, a Foundation pick keeps the buyer's paint: Gloss is the safe default under sponsors and numbers, Matte or Flat Black give a dead-flat look, Candy gives a deep coloured-glass look, and Brushed plus a brushed-grain Spec Pattern Overlay gives visible grain.
- The shelf also carries five named specialty tiles with built-in texture: Dragon's Pearl Scale, Moonstone, Sentient Polycarbonate, Orchid Shift Pearl and Black Diamond Candy. They sit under the same keep-source-paint rule, though the tools report that they bring their own palette; use Use finish's own color to show it.
- Foundation EFX (about 46 tiles) is the textured companion shelf: foundations with holographic foil, frost, mercury, kintsugi, obsidian, damascus and stardust that carry their own paint and spec. Picking one keeps the car's paint (Use source paint) and applies its spec; switch Base Color to "Use finish's own color" to see its own paint.

## Finishes that bring their own colours versus finishes that take the zone colour
- A finish that takes the zone colour is a material: it gives shine and texture and wears whatever colour the zone has. Chrome, Candy, Pearl, Satin, Brushed and textures such as Multi Carbon Micro and Worn Chrome are examples.
- A finish that brings its own colours carries a palette (Chameleon Aurora's green-blue-purple shift, Candy Flame, every Cultural tribute livery), and the zone shows that palette until the buyer sets a colour mode. Most finishes in the catalogue are of this kind; the ones that take the zone colour are mostly the Foundation sheens and plain-material textures.
- The app marks this in the Base Color dropdown: "Use finish's own color" for its palette, "Use solid color" or "Use source paint (spec only)" to override it. The tools mark it per row: "takes the zone colour (set color)" or "brings its own palette (use color 'finish')".
- spb_find_finishes can filter on it with own set to own or takes; spb_finish_details shows the palette of an own-colour finish.
- When the buyer names a colour for a finish that brings its own palette, either choose a finish whose palette already matches, or set a solid colour and accept that the palette is replaced.

## Specials versus base + pattern + spec overlay
- Every finish is picked into the same Base slot, but the picker holds two kinds. Bases live in FOUNDATIONS and THE CORE COLLECTION: a base is a material defined by its metal, roughness and clearcoat values, and some bases also carry artwork (Flames, FAR OUT, SHOKK WORKS, ASTRA). Specials fill FRACTURED, SHOKKER, CULTURAL, COLOR SCIENCE and FUSION LAB: a special (also called a monolithic finish) is one tile that brings its own paint and its own spec as a matched pair, so the zone normally shows From special.
- A Foundation base changes only the shine and leaves the livery visible. A special replaces the zone's look with its own artwork, which is why Rust, Hologram Metal, a Cultural tribute or a Prizm shift read as a finished surface the moment they are picked.
- Base + pattern + spec overlay is the assembled approach: the base sets the shine, the zone's PATTERN section lays a design over it (its Strength slider runs 0-100%: "0% removes the effect; 100% applies full strength"), and spec overlays add metal, roughness and clearcoat detail on top of the paint.
- The SPEC OVERLAYS section of the picker describes its tiles as fine material constructions for existing paint: they stack their metallic, roughness and clearcoat detail on the buyer's livery.
- Choose a special (or a base with artwork) when the buyer names a whole surface such as rust, carbon weave, hologram, patina or flames. Choose a Foundation base when they only want a different sheen on the same colour. Choose base + pattern + spec overlay when they want a plain colour with a designed texture that can be scaled and rotated independently. spb_finish_details says whether a given finish brings its own colour.

## Sections and shelves in the picker
- Finishes appear as category cards grouped under section headings; clicking a card opens that category full size, and "← ALL CATEGORIES" goes back. Each section header shows "N categories · M finishes". Counts below are approximate.
- FOUNDATIONS (2 categories, about 70 finishes): Foundation Bases, Foundation EFX.
- THE CORE COLLECTION (11, about 540): ASTRA, FLAW LAB, SHOKK WORKS, FAR OUT, BAD & RAD, ALL THAT, TACTICAL & FIELD, CYBERPUNK, Flames, Sock Hop, Groovy Vibes.
- FRACTURED (13, about 750): FRACTURED FLAMES, MINDS, SOULS, FORGE, NIGHTSHIFT, WILDS, ELEMENTS, COSMOS, RELICS, OPALFIRE, TESSERA, FOUNDRY and FRACTURED SHOKK; generative finishes that shatter, flow, burn and bloom.
- SHOKKER (17, about 670): PARADIGM, PRISM FORGE, WORLD OF COLOR, MORTAL SHOKK, MONEY SHOKK, NEON UNDERGROUND, ANIME INSPIRED, IRIDESCENT INSECTS, Shokk Series, DARK CITY, X LAB, IMPOSSIBLE FINISHES, Signal, GRUNGE & FUN, Glass & Surface, SOURCE PATTERN PLATES and one more small shelf.
- CULTURAL (5, about 185): RISING SUN, VIVA MEXICO, UNION JACKED, FORBIDDEN DRAGON, LET FREEDOM RING; hand-built tribute collections of layered art.
- COLOR SCIENCE (4, about 200): Prizm, Color Clash, Gradient Directional, Gradient Extended; finishes where colour is the whole point.
- FUSION LAB (6, about 240): GRADIENTS, Spectrum Shift, Light & Optics, Surface & Grain, Depth & Geometry, Materials & Physics.
- Shelf names carry small emoji or star prefixes on screen; leave them off when passing a shelf to a tool, where a partial name such as "WILDS" or "Prizm" is enough.
- When a spec overlay is being picked instead of a base, the first section is SPEC OVERLAYS.

## Search, filters and tag chips
- The search box says "Search titles, descriptions, ids, or #tags..." and its heading reads "Search finishes: Type a name, id, description, or #tag".
- Filter buttons: All, Favorites, Showcase. Sort buttons: Grouped, My Rating, A-Z.
- A "Dig in:" row of #tag chips with counts jumps to a look; the first 14 show and "+N more" opens the rest. Tags include #carbon, #chrome, #metallic, #candy, #pearl, #chameleon, #fire, #ice, #galaxy, #matte, #gold, #neon, #glass, #crystal, #copper, #grunge, #scales and #luxury, with more such as #tactical, #racing, #retro, #dark, #rainbow, #usa and #japan.

## Finding finishes with the tools
- Finish keys come back in the search rows; copy a key exactly as a row returns it and never build one by hand.
- spb_suggest_finishes ranks the whole catalogue for this car. Give it ask (the buyer's own words), part, goal (pop, premium, shimmer, deep, retro, stealth, readable, subtle), novelty (safe, balanced, wild), and a coverage option (keep = shine only, complete, texture). like plus mods (calm, bold, darker, lighter, glossier, flatter, sparklier, warmer, cooler, vivid, muted...) means "like X but calmer". An option to leave out unwanted traits drops them, and exclude takes keys already shown so the next page gives new options. Rows carry look, why, loud and busy ratings 1-5, and an apply hint.
- spb_find_finishes searches by meaning with query plus filters: colour, shine (mirror, gloss, satin, matte), metal (none to full), sparkle, texture, own (own or takes), shelf, type (finish, base, monolithic), tags, a minimum-quality filter and exclude. It returns up to 10 rows of key, name, look and about. Use several differently worded queries.
- spb_browse_catalog with no argument returns the map of all shelves; with a shelf it returns that shelf's best items.
- spb_finish_details takes one key or name and returns the full sheet: palette, own or takes colour, measured metal, roughness and clearcoat, scale, sparkle, quality and best use.
- spb_compare_finishes lays up to 6 keys side by side.
- Some search rows come from shelves the picker does not show. The buyer cannot find those by browsing, so prefer finishes that live on a picker shelf and say the name exactly as the picker shows it.
- Typical flow: spb_suggest_finishes with the buyer's words to get 2-3 options -> spb_finish_details on the favourite -> apply with the zone-editing tool using its key and a colour choice -> render -> adjust.

## Looks and example finishes
Names are as the picker displays them, with the shelf in brackets. Check a pick with spb_finish_details before applying.
- Mirror chrome: Chrome, Dark Chrome, Satin Chrome (all Foundation Bases; all take the zone colour).
- Gold chrome: there is no plain gold-chrome tile. Use Chrome with a solid gold colour, or the gold finishes Chronograph Gold (ASTRA, watchmaker gold with engraved patterns) and Van: Eagle Gold (FAR OUT, mirror-bright gold leaf outlined in black).
- Satin: Satin, Satin Pearl, Semi-Gloss (all Foundation Bases).
- Matte and flat: Matte, Eggshell, Primer, Flat Black (Foundation Bases), Chalked Paint (Foundation EFX).
- Candy: Candy (Foundation Bases, polished metal under the colour you pick), Black Diamond Candy (Foundation Bases, near-black candy over fine diamond flake), Candy Flame (Flames).
- Pearl: Pearl, Satin Pearl (Foundation Bases), Mother of Pearl and Pearl Oyster (FRACTURED WILDS).
- Metallic and flake: Metallic (Foundation Bases, flat metallic with no baked-in flake), Van: Metalflake Blue and Van: Metalflake Red (FAR OUT, big flake laid heavy under clear), Sparkle Diamond Dust (Light & Optics), Multi Flake Grain (Surface & Grain).
- Carbon fibre: Multi Carbon Micro (Surface & Grain, takes the zone colour), Gradient Carbon→Chrome (Gradient Extended), Hardware: Carbon Handguard (TACTICAL & FIELD), Carbon Voltage (NEON UNDERGROUND, cyan and violet seams).
- Colour-shift and flip: Chameleon Aurora, Chameleon Amethyst, Chameleon Copper (Prizm), Orchid Shift Pearl (Foundation Bases).
- Holographic and prismatic: Hologram Metal and Dichroic Skin (X LAB), Hologram Noir (IMPOSSIBLE FINISHES), Holographic Foil (SHOKK WORKS), Prizm Holographic (Prizm).
- Brushed metal: Brushed (Foundation Bases, add a brushed-grain spec overlay for visible grain), Aniso Horizontal Chrome and Aniso Crosshatch Steel (Surface & Grain), Brushed Satin Alloy (SHOKK WORKS).
- Worn, rust and patina: Rust, Worn Chrome, Weathered Paint (Surface & Grain), Bornite Patina (FRACTURED WILDS), Copper Patina (Gradient Directional).
- Neon-bright: Neon Underglow, Split Underglow and Blacklight Garage (NEON UNDERGROUND); they are painted looks of lit colour on a dark body, so describe them as neon-style paint.
