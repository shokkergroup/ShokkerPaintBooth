# Zones and stacking

## Core facts
- A zone is one area of the car plus one look (base material, colour, paint pattern, spec patterns, strengths), and the whole livery is the list of zones in the ZONES panel.
- Zones never blend or stack on a pixel: where two zones claim the same pixels, the zone nearer the top of the list wins outright and the one below gets nothing there, so lowering the top zone's intensity never reveals the zone below. The tools call the top position 0 ("lower index wins") and spb_add_zone puts a new zone on top by default.
- The last default row, Everything Else, is the catch-all: it only ever gets the pixels no other zone claimed, wherever it sits, so moving it up the list changes nothing; keep it and edit it to change the car's base look.
- Layered looks are built inside ONE zone (a base, up to 5 paint patterns, up to 5 spec overlays per base, and 2nd to 5th base overlays), not by overlapping zones; reuse and stack before adding, and to start over call spb_reset_zones and edit the catch-all instead of muting zones one by one.
- Follow-ups on the zone just changed ("smaller", "rotate it", "brighter") go through spb_tweak, and "undo that" goes through spb_undo; never rebuild by hand.

## Contents
1. What a zone is
2. The zone list and its buttons
3. Zone order: which zone wins
4. The catch-all: Everything Else
5. Choosing a zone's area in the app
6. Choosing a zone's area through the tools
7. Zone economy and the zone tools
8. Worked example: pink camo with a rattlesnake spec
9. Worked example: matte black, chrome roof, carbon hood
10. When a zone shows nothing

## 1. What a zone is
- A zone has an AREA (which pixels it covers) and a LOOK (what those pixels become). The area is a picked colour, a drawn region, a layer restriction, a named part (tools only) or "Remaining". The look is a base material, a colour mode, up to 5 paint pattern layers, spec overlays, optional 2nd to 5th base overlays, and strengths.
- Click a zone's card and the zone panel opens (titled ZONE POPOUT PANEL, header with the zone number and name, and a "Reset Zone" button that resets that zone to defaults). Its sections are COLOR ("What pixels does this zone cover?"), APPLY AREA (collapsed until used), BASE, SPEC OVERLAYS and PATTERN (both inside the BASE area), then OVERLAYS (2nd, 3rd, 4th, 5th base overlay).
- A zone also has an intensity, shown as a percent badge on its card (zones made with + Add Zone start at 100; of the five default zones, Zone 4 starts at 80 and Everything Else at 50). It is not a slider in the zone panel; set it with spb_edit_zone or spb_tweak (change intensity). It scales the finish's shine/metal, its paint effect and its brightness boost together; 100 is full strength.
- A zone paints only when it has BOTH a look and an area. See section 10 for the status dots.

## 2. The zone list and its buttons
- Header: "ZONES (n)" and the hint "Top → Bottom". A fresh project has 5 zones: Zone 1, Zone 2, Zone 3, Zone 4 and Everything Else.
- Each card, left to right: the ☰ handle (title "Drag to reorder"), the zone number, a status dot, a colour dot, the name box (type in it to rename), a summary such as "Gloss + Camo" (base, then pattern, then +N for extra pattern layers; "(not set)" when empty) with the intensity badge, a 🎯 mark when a region is drawn, the eye button (mute), ⧉ (duplicate), a link button, and × (delete).
- Mute (eye): "Temporarily disable this zone without deleting it". A muted zone is left out of the render and keeps its place; click again to unmute.
- Duplicate (⧉): makes "<name> (copy)" just below the original and selects it. Because the original is higher, it wins where the two overlap.
- Delete (×): asks you to confirm when the zone has a finish, colour or drawn region ("Ctrl+Z brings it back"). The last remaining zone cannot be deleted ("at least one zone is required").
- Reorder: drag the ☰ handle (hover text "Drag to reorder") up or down.
- Keyboard: N adds a zone, Shift+M mutes or unmutes the selected zone, Shift+Delete deletes it. The keys do nothing while you type in a text box or a dialog is open.
- Link button (hover text "Link this zone to another"; "Linked (click to unlink)" once linked): asks which zone number to link with. Linked zones share base, pattern, finish, intensity, scale, rotation, pattern opacity and stack, wear and all Base Color settings, so changing one changes the others. Colour picks and drawn regions are NOT shared, so each keeps its own area.
- Under the list: "+ Add Zone" (creates a new empty zone named "Zone N" at the BOTTOM of the list, below Everything Else, and scrolls to it), "Reset All Zones" (confirm dialog; returns to the default 5 zones; Ctrl+Z brings the old setup back) and "⋮ More" (Presets Gallery, Rand Current Zone, Rand All Zones, Apply Finish to All, Shokker Library, Undo History and more).
- Limit: 50 zones ("Zone limit reached"); from 30 zones a warning says performance may degrade. Most cars need 2 to 4 zones.

## 3. Zone order: which zone wins
- Zones are applied from the top of the list down and the FIRST zone to claim a pixel keeps it. Zone 1 (top) claims first; zones below get what is left. The tools express this as "lower index wins" (index 0 = top).
- Zones NEVER blend with each other. A lower zone does not show through a higher one at any intensity or opacity. To layer a look (camo over candy, flake under a stripe), put the layers in ONE zone: its base, Pattern 1 plus up to 4 more pattern layers, up to 5 spec overlays, and the OVERLAYS section's 2nd to 5th base overlays.
- One exception: a zone chosen by colour or by layer (no drawn region) takes pixels back from zones above wherever you paint them in with the toolbar's Include Region brush ("Include Region - paint areas to keep in zone color match"); Exclude Region removes areas from its colour match.
- To make a small detail show where a big zone already covers it, the detail zone must sit ABOVE the big one. In the app, drag its ☰ handle up. Through the tools, spb_add_zone puts the new zone on top unless priority says "bottom" or a position number (0 = top).
- A zone added with the app's "+ Add Zone" button lands at the bottom, so it loses every overlap against the zones above it until it is dragged up.
- spb_get_zones shows, for each zone, what it covers and a visible share (the part it really wins). A zone whose visible share is near 0 is covered by zones above it, so changing its look shows nothing; move it up or give it another area.
- The "Remaining" zone is filled after all the others have claimed their pixels, so it works wherever it sits in the list: dragging Everything Else to the top does NOT let it take other zones' pixels. Keeping it last is only a convention.
- The "Hard Edge" checkbox in the COLOR section is ON by default for every zone; it removes soft blending at the zone border so edges stay crisp.

## 4. The catch-all: Everything Else
- It is the last default row. Its colour mode is "Remaining" and its hint reads "Safety net - catches any pixels not claimed by zones above". Default look: Gloss base at 50 percent intensity.
- It covers whatever the other zones leave, so it is the right zone to edit for the car's base look ("make the car matte black" = edit this zone). Zones above it then add the parts, stripes and details.
- Do not delete it: nothing else would catch the pixels the other zones miss. spb_reset_zones always keeps it.
- "Remaining" is the only special-colour chip in the COLOR section. Its tooltip: "Catches any pixels not claimed by higher-priority zones".

## 5. Choosing a zone's area in the app
Everything below is in the COLOR section or the left toolbar.
- PICK COLOR FROM CAR (toolbar button "Color", key I): arms the eyedropper. Click the car; the first click sets the zone's colour and each further click ADDS another colour ("multiple colors can be selected").
- HEX box, the colour wheel and "✓ Apply" set a colour by value. "+ Add Color" adds another; "Clear All" removes them; × on a colour chip removes one.
- Color Match slider on every picked colour: "Exact" to "Loose", range 0 to 100, default ±40. Exact grabs only that colour; Loose also grabs nearby shades (shadows, highlights, gradients).
- RESTRICT TO LAYERS (shown when the paint has PSD layers): tick the layers the zone may paint on; the status line reads "All layers (no restriction)" or "Restricted to N layer(s): names"; hidden layers are flagged "Hidden (not painting)"; a clear button removes the restriction.
- Drawn regions: toolbar Magic Wand (key W; Tolerance 0 to 255, default 32; "Contiguous" on by default; Shift adds, Alt subtracts), Lasso (L), Rect = Rectangle Select (M), Brush (B), Fill (K). A zone with a drawn region shows the 🎯 mark; all drawn pixels get that zone's look whatever their colour.
- APPLY AREA (collapsed until used): "Draw box" or "Lasso", then "Activate"; "Refine color" keeps the colour match but limits it to the area you brush; "Clear" removes it. The option "Fit pattern/base swatch into box" scales the pattern/base into the drawn box (leave it OFF for complete special finishes).

## 6. Choosing a zone's area through the tools
Always place looks on NAMED PARTS (region with a part), never on big grid boxes.
- part: "left side", "right side", hood, roof, trunk, spoiler, front bumper, rear bumper (spb_status lists what this car really has; some cars also have bed, windshield, rear window). Everyday words resolve: driver side = left side, bonnet = hood, boot = trunk, nose = front bumper, wing = spoiler. A list of parts is allowed.
- portion: "front third", "lower third", "rear half" and similar, or a band with axis height or length plus from and to (height 0 = roof-line to 1 = rocker; length 0 = front to 1 = rear).
- colours: a list of hex values plus a tolerance of 6 to 100. layers: exact layer names from spb_status. element: numbers, sponsors or stripes (flat paints; call spb_describe_paint first). exclude: numbers, sponsors, stripes. cells or a rectangle only for details under about 12 percent of the sheet.
- remaining (everything not claimed) and everything with paintable (a whole-car base) need confirm:true and the buyer's words naming the whole-car change.
- A part the car map does not list: do not guess; ask for a picture with it circled or a rough place on the sheet. When spb_status reports key parts missing, call spb_request_parts.
- The add/edit result says what the region selects, which zones it took pixels from, and a measured verdict; report those, not what you intended.

## 7. Zone economy and the zone tools
- spb_get_zones: every zone with id, name, coverage, visible share and look. Call it before adding anything.
- spb_add_zone: a NEW zone; region required; goes on top by default. Pass the buyer's own words in the required buyer-words field.
- spb_edit_zone: change an existing zone, found by zone id (best), unique zone name, or index plus an expected name. Pass only what changes. A zone covering most of the car needs confirm:true.
- spb_duplicate_zone: copy a zone (the copy sits just below it), optionally changing settings on the copy.
- spb_reset_zones: START FRESH in one call. Removes every zone except the catch-all and any zones named in keep; one undo step; needs the buyer's words and confirm:true.
- spb_tweak: one property of the zone you just changed ("working zone") or the zone you name: scale, rotation, brightness, hue, saturation, shine, metal, opacity (pattern strength), intensity (finish strength) or colour (with a target hex). Direction up or down; amount "a bit", "normal", "a lot", or degrees for rotation. Typical steps: rotation 15 / 30 / 90 degrees; opacity or intensity 15 / 25 / 40 points (kept between 5 and 100); a "smaller" scale step multiplies the scale by roughly 0.6.
- spb_undo: steps default to 1; "undo both" = 2; "back to the original" = every change made to that part in this chat. Always use it instead of re-setting a colour by hand.
Rules of economy:
1. Reuse: if a zone already covers the part or sits empty, edit it instead of adding.
2. Stack inside one zone: finish + colour + pattern + spec patterns belong together; do not add a zone per effect.
3. New base over most of the car: spb_reset_zones (keep what the buyer still wants), then edit the catch-all. Never one mute call per zone, and never mute or delete the buyer's zones unless they asked.
4. Iterate on the same zone with spb_tweak ("smaller", "pinker"); a new zone for a follow-up is wrong.
5. A pattern added to a zone with no base gets a Gloss base automatically.
6. After the LAST change of a request call spb_render once and report seconds and files saved.

## 8. Worked example: pink camo with a rattlesnake spec
Buyer: "Make the whole car pink camo with a rattlesnake texture." The catalogue has no such single look, so stack it in one zone.
1. spb_status for parts and zone count. spb_find_patterns "camo" looks for the camo patterns, for example Camo (digital blocks) and Multicam (organic blobs); spb_find_spec_patterns "snake scales" looks for spec patterns such as Snake Scale Diamond (shelf Predator Skins) and Snake Scales (shelf Organic & Natural). Copy the ids exactly from the results.
2. The buyer named the colour, pattern and whole car, so the request is concrete: use confirm:true. spb_reset_zones (keep only zones the buyer still wants, such as their number or sponsors).
3. spb_edit_zone on "Everything Else": colour a pink such as #ff4fa3; pattern Camo with opacity about 30; spec pattern Snake Scale Diamond at opacity about 60 (the panel calls this Strength). At opacity 100 the pattern's own earth-tone colours cover the pink; around 70 hot pink reads brown; 25 to 35 keeps the pink and adds the camo texture.
4. spb_preview (with the spec map on) and the measured result; say what you chose and offer alternatives: Multicam for a softer camo, Snake Scales for a different scale shape.
5. Follow-ups: "camo smaller" = spb_tweak scale down; "more pink" = spb_tweak hue toward pink; "stronger snake texture" = spb_edit_zone with the full spec pattern list (it REPLACES the existing list).
6. spb_render once.
A spec pattern changes only metal, roughness and clearcoat, never colour, so it shows as sheen differences on the car and in the spec preview, not in the flat colour preview. If the buyer wants snake scales visible as paint, use the paint pattern Snake Skin 3 ("hourglass saddle-shaped viper scales like rattlesnake dorsal markings") instead of Camo, or add a second pattern layer in the app with "+ Add Layer" (the tools set only the first pattern).

## 9. Worked example: matte black, chrome roof, carbon hood
Buyer: "Matte black car, chrome roof, carbon fibre hood."
1. spb_reset_zones (confirm:true) if this replaces an existing livery. spb_edit_zone on "Everything Else": finish Matte, colour near-black such as #1a1a1a. Base values of Matte: metal 0, roughness 200, clearcoat 160.
2. spb_add_zone, region part roof, finish Chrome with a near-white colour for silver chrome (a dark colour gives a dark tinted chrome, because the sim multiplies the paint colour by the metal).
3. spb_add_zone, region part hood, finish Gloss (metal 0, roughness 30, clearcoat 16), colour #1a1a1a, pattern Carbon Fiber, scale below 1 for a finer weave. For a COLOURED carbon (red carbon) keep the pattern opacity around 25 to 35 so the zone colour shows.
4. Both new zones sit above the catch-all, so they win their parts; they do not overlap each other, so their order does not matter.
5. spb_render once. Follow-up "make the weave smaller" = spb_tweak scale down on the hood zone.

## 10. When a zone shows nothing
Status dot on the card (hover for the text):
- Green "Will render". Orange "No finish assigned" (pick a base in BASE). Orange "No color/region — zone targets nothing" (use Pick Color or draw a region). Grey "Empty zone — set color & finish". Red "Missing source layer - zone will paint nothing" (rebind or clear RESTRICT TO LAYERS). Grey "Muted (excluded from render)" (click the eye).
- A green zone can still show 0 percent because zones above it cover its pixels: check spb_get_zones and the order.
- Colour dot with a warning mark = no colour picked yet.
