# Tools and menus in the Shokker toolbar

## Core facts
- The toolbar under the header has always-visible buttons (Move, Pick, Color, Wand, Lasso, Rect, Brush, Fill, Erase, Text) followed by menus: History, Select, Retouch, Mask, Spec Tools, Transform, Adjust, Material / Spec and Car, and on narrow windows the menus that do not fit fold into one Menus overflow.
- A ZONE / LAYER switch on the toolbar decides whether the tools edit zone masks or the pixels of the selected layer, and the options strip under the toolbar shows the active tool's sliders (Size, Opacity, Hardness and so on).
- Spec work has its own tools: SPEC SCULPT in the header, the Spec Tools menu (Decal Rescue Kit, Lighting Mask, Material Sampler, Range Remapper, Spec Doctor) and the Material / Spec menu (Material Brush, Spec Brush, Wear Brush, Layer Materials, Auto Spec, Flake Studio).
- The Car menu holds the tools that know the car's shape: Mirror Paint, Mirror To Other Side, Car Stripe, Number Kit, Sponsor Kit, League Pack, Car-Space Fade and Race Wear; Shokk Drop (header button) imports art and spec maps.
- Through the MCP tools, spb_kit does the Number Kit, Sponsor Kit and spec checks when it is available, spb_undo takes changes back, spb_tweak adjusts the zone being worked on, and spb_add_graphic draws shapes on named parts.

## Contents
- Layout, modes and the options strip
- Selecting and picking colour
- Brushes and retouching
- Mask menu, Transform and Adjust
- History and undo
- Spec Tools menu
- Spec Sculpt and Auto Spec
- Material / Spec menu: brushes, Layer Materials, Flake Studio
- Car menu: mirror, stripe, numbers, sponsors, league, fade, wear
- Shokk Drop
- MCP side
- Buyer words and which tool

## Layout, modes and the options strip
- Always-visible buttons, with keys: Move (V), Pick (Y), Color (I), Wand (W), Lasso (L), Rect (M), Brush (B), Fill (K), Erase (E), Text (T). Transform is Ctrl+T from the Transform menu.
- **ZONE** / **LAYER** switch: Zone mode edits zones and masks only; Layer mode edits the selected layer only. Move and Pick Item (click a sponsor, number or shape to move, rotate or scale just that piece) are Layer-mode tools.
- Under the toolbar the active tool is named in capitals with a one-line hint, then its options. Brush family: **Size** 2-600 px (default 40; [ and ] keys step it), **Opacity** 1-100% (keys 1-9 jump), **Hardness** 0-100% (0 soft, 100 hard; default 100), **Flow** 1-100, **Spacing** 1-200% of brush size (default 25), **Smooth** 0-100 (default 10), **Stab** 0-200 px (default 0).
- Brush shapes: Round, Square, Diamond, Slash, Noise. Eraser modes: Soft (Brush), Hard (Block), Clear Current Target.
- The header holds SPEC SCULPT, Shokk Drop and Encyclopedia buttons; the toolbar's right side holds RENDER HISTORY (a dropdown of the last 20 renders; a thumbnail click rebuilds that render).
- Buyer words: "paint on the layer only" = Layer mode; "just edit the zone mask" = Zone mode.

## Selecting and picking colour
- **Color** (I) picks a colour from the paint. Options: sample size Point Sample, 3×3 Average, 5×5 Average or 11×11 Average, and Sample: All Layers or Current Layer.
- **Wand** (W): click to sample a visible colour; Shift adds, Alt subtracts. Tolerance 0-255 (default 32), a sample-size list, a Contiguous tick, an Anti-alias tick and a Quick Select tick (paint over the area and the selection grows to its edges; brush size 2-600 px, default 40).
- **Lasso** (L): drag freehand or click polygon points; Enter closes, Backspace removes a point. **Rect** (M) drags a rectangle; pressing M again gives the elliptical marquee. Shift adds, Alt subtracts.
- **Select menu:** Select All Color (A), Color Range… (fuzziness plus Add and Subtract eyedroppers), Grab Object (Shift+W: click a number or logo to select it with its outline and shadow), Smart Region Fill (Shift+W twice), Move Selection Border (Arrow 1 px, Shift+Arrow 10 px), Pick Layer Element, Zone Pick, Elliptical Marquee, and **Material…** (select by material in the spec map: click a spot or use a preset such as All Chrome, All Matte, All Gloss Clear; Tolerance 0-80 default 12, Soft Edge 0-64 default 6, Apply As Replace / Add / Subtract).
- Selection options: Feather 0-50 px (0 = hard edge), Smooth radius 1-250 px (default 2). With the Lasso a Magnetic tick snaps the border to nearby edges: Width 1-256 px (default 10), Contrast 1-100% (default 10), Frequency 0-100 (default 57).
- Buyer words: "select just the number" = Grab Object; "select everything chrome" = Select > Material…; "select all the red" = Select All Color or Color Range….

## Brushes and retouching
- **Brush** (B) paints the zone mask or the selected layer's pixels; **Erase** (E) removes them; **Fill** (K) fills by sampling the active layer (Layer mode) or the whole image (Zone mode); **Text** (T) types live text on the car (font size 8-800 px, default 120; outline 0-20; letter spacing -10 to 50; line height 0.5-3).
- **Retouch menu:** Color Brush (C) paints solid colour or a pattern brush on the selected layer; Recolor (Shift+B twice); Healing Brush (J: Alt+click clean texture, then paint); Clone Stamp (S: Alt+click the source; Aligned tick, Opacity 1-100); Smudge (Q; strength 1-100, default 50); Blur Brush (R) and Sharpen Brush (R twice; strength 1-100, default 50); Dodge (O) and Burn (Shift+O) with range Shadows / Midtones / Highlights and Exposure 1-100 (default 20); Pencil (Shift+B: a hard, aliased pixel line); History Brush (Shift+Y) and Save History Snapshot (paint back saved pixels); Gradient (G) with types Linear, Reflected, Radial, Angular, Diamond, Conical, Spiral CW and Spiral CCW.
- Layer-only tools work on the selected layer. With a zone that is restricted to layers, tick **Clip to <zone>** to keep strokes inside that zone.
- Buyer words: "soften the edge of that stripe" = Blur Brush; "remove that scratch" = Healing Brush or Clone Stamp; "darken the corners" = Burn; "gradient from red to black" = Gradient.

## Mask menu, Transform and Adjust
- **Mask menu** (zone selections): Grow 1 px, Grow 2 px, Shrink 1 px, Shrink 2 px, Fill Holes, Feather 2 px, Smooth Edges, Refine Edge… (make the edge follow a real logo or number edge, with live preview), Invert Mask, Copy Mask (to another zone), Mirror Mask, Include Region, Exclude Region and Erase Spatial (paint areas to keep in or take out of a zone's colour match).
- **Transform menu:** Transform (Ctrl+T: the selected layer or selection in Layer mode, the zone's pattern in Zone mode) and Fit Layer to Zone Selection.
- **Adjust menu:** Brightness / Contrast, Hue / Saturation, Color Replace (one colour to another everywhere), Invert Colors, Grayscale, Gradient Map, Vibrance, Color Temperature, and **Colourway Studio…** (the same livery in several colourways: teammates, sponsors; Save As Variant, Make Team Colourway, Apply Colourway).
- Buyer words: "make my teammate's car blue" = Colourway Studio; "make the edge crisper around the logo" = Refine Edge….

## History and undo
- **History menu:** Undo (Ctrl+Z), Redo (Ctrl+Y or Ctrl+Shift+Z) and Undo History… (a list of recent actions). Right-click also offers Undo and Redo.
- Number Kit and Sponsor Kit each add their work as one undo step, and mirrored copies undo with Ctrl+Z. The spb_undo tool takes back changes made through the tools.

## Spec Tools menu
- **Decal Rescue Kit…** gives the active zone selection a safe material under sim-stamped numbers and sponsors: Flat Vinyl (M 0, R 100, CC 110), Satin Decal (M 0, R 100, CC 75) or Gloss Decal (M 0, R 42, CC 22). Select the stamp footprint first (grow it with Mask > Grow); paint colours and layer pixels are untouched.
- **Lighting Mask…** edits only the spec alpha channel for the selected area: Use Source Alpha, Full Lighting, Reduced Lighting (half strength, for recessed vents and seams) or Kill Lighting (fake holes, grille openings; not a shortcut for matte).
- **Material Sampler…** shows the spec map by channel (R metal, G roughness, B clearcoat, A specular mask) and reads the exact M, R, CC and A at a click (sample area Point, 3×3 Median or 5×5 Median). Apply makes the active zone selection that one sampled material and keeps paint pixels. Material tolerance 0-64 (default 12).
- **Range Remapper…** squeezes a zone's Metallic, Roughness and Clearcoat into a new Low-High range (0-255 each) while keeping scratches, weave and flake; presets Original, Metallic Texture, Printed Vinyl, Matte Texture and Gloss Texture; Restore Original undoes it.
- **Spec Doctor** (also in Material / Spec): Run Check renders the spec map and lists findings with Show, one-click fixes and Ignore. It catches chrome over near-black paint, a clearcoat value that means no coat, a dull coat on a mirror-smooth area, no clearcoat anywhere, decal layers that took the body's chrome, one material on the whole car, spec offset from the paint, and pixel noise that will shimmer.
- Buyer words: "my number turned to chrome" = Decal Rescue Kit; "cut out the grille so it looks dark" = Lighting Mask; "what is the spec here" = Material Sampler; "check my spec" = Spec Doctor.

## Spec Sculpt and Auto Spec
- **SPEC SCULPT** (header) gives the whole car a spec look from the colours of the paint; spec only, the paint is not touched. Looks: Pop, Stealth (matte body, gloss graphics), Showroom (deep candy body, gloss graphics, pearl whites), Chrome Trim (the thinnest accent colour turns chrome), Satin Race. The panel lists Your Colours, a studio Light (Studio and Sweep buttons on the Live Preview) and the Spec Mix. **Keep Look** commits (Ctrl+Z steps it back), Cancel steps it back, **Classic Lab** opens the older spec window for spec files from disk, batch folders and photo matching.
- **Auto Spec…** (Material / Spec) proposes one material per layer for the whole car: a Showroom to Race-Worn slider (0-100), a layer list where each material can be changed or left to the zones, a Live Preview tick, Rescan and **Apply Auto Spec**.
- Buyer words: "make the whole car look expensive" = Spec Sculpt Showroom; "matte car with glossy graphics" = Stealth; "give each layer a believable material" = Auto Spec.

## Material / Spec menu: brushes, Layer Materials, Flake Studio
- **Material Brush** (U) brushes any catalogue finish onto the car; modes Paint + Spec, Spec only (paint stays) and Paint only; sliders Scale, Rotation 0-355°, Strength 0-200%, Spec strength 0-200%, colour depth or strength 0-100%; Alt erases. **Spec Brush** paints only metallic, roughness and clearcoat from presets, exact values or any finish. **Wear Brush** writes dirt, rubber marks or stone chips (paint and spec together). **Spec Eyedropper** picks the paint and spec under a click to brush with. **Clear Material Strokes** removes them all (Ctrl+Z brings them back).
- **Layer Materials…** gives the selected layer its own material (Gloss Vinyl, Matte Vinyl, Satin, Chrome Foil, Brushed Metal, Holographic, Carbon); its spec follows the layer. **Shine Lens** shows paint and spec under a studio light on the Live Preview.
- **Flake Studio…** designs metallic flake and pearl that still read in iRacing. Looks: Fine Silver, Bass-Boat, Candy Over Flake, White Pearl, Colour-Shift Pearl, Satin Metallic. Target: Zone, Material Brush or Layer. Sliders: Flake Size 0.05-3 cm, Density 0-1, Sparkle 0-1, Base Metal 0-255, Base Rough 15-255, Flake Metal 0-255, Flake Rough 15-255, Clearcoat 16-255, optional Flake Colour and Pearl Colour. Sim-Safe adds a coarser flake band; Distance 0-4 shows how much flake survives at each viewing distance. Buttons Shine Lens, Remove, **Apply To Zone**.
- Buyer words: "bass boat flake on the hood" = Flake Studio Bass-Boat on a hood zone; "add dirt behind the wheels" = Wear Brush; "put chrome only on the sponsor layer" = Layer Materials.

## Car menu: mirror, stripe, numbers, sponsors, league, fade, wear
- **Mirror Paint** makes Brush, Eraser and Retouch strokes land on the matching part (left side and right side, both halves of hood, roof, trunk and bumpers). **Mirror To Other Side** copies the selected layer or selection to the matching part, fitted to that side. **Copy To Other Side (Text Reads Right)** turns numbers and lettering so they read correctly. **Re-Measure Car Sides** re-reads the car after a template change.
- **Car Stripe…**: Width 2-600 px, Offset -600 to 600 px, Twin (with Gap 0-600 px), Colour, Bumpers; **Add Stripe** centres it on hood, roof and trunk, lined up at every seam.
- **Number Kit…** (place group "Place On The Car"): Number (1-4 letters or digits), Font, Bold, Italic, Slant 0-25°, Gap -10 to 40%, Fill, Outline 1 and Outline 2 (0-25%), Shadow (Dist 0-20, Soft 0-12), Panel (Rounded Box, Oval, Circle, Square), Places Left Door / Right Door / Roof, Roof reading side, Size 30-140%, Material (None, Chrome Foil, Gloss Vinyl, Satin Vinyl, Matte Vinyl), Turn Each Place, Replace Existing or Add Alongside, then **Add Number Kit** (one undo).
- **Sponsor Kit…**: Choose File… or Use Selected Layer; Remove Box (Tolerance 0-80, Edge 0-4); Slots (Left Door, Right Door, Left and Right Rear Quarter, Left and Right TV Panel, Hood, Trunk / Deck, Left and Right Roof Rail); Size 20-300%; Material (None, Chrome Foil, Gold Leaf, Gold Foil (solid), Matte Vinyl, Gloss Vinyl); Extra Turn; **Add Sponsor Kit**.
- **League Pack…**: tabs 1 Roster, 2 Look, 3 Preview & Render. Roster from Import File… (csv, tsv or txt) or Paste Rows (Driver Name, Customer ID, Number, Team Colour, Sponsor Logo, Name Text). Look: Places, Font, Fill, Outline, Shadow, Size 40-160, Replace Every Number On The Car (Including Small Ones), Use The Team Colour Column, Add A Name To Every Driver (Roof Rails, Rear Quarters, TV Panels, Hood, Trunk; size 30-200), logo files. Pack Folder: each driver renders into a sub-folder named by customer ID. Buttons Preview All, Render All, Apply This Driver To The Project.
- **Car-Space Fade**: Direction Nose → Tail, Bottom → Top, Centre → Out or Custom; Reverse; Pick 2 points; Parts chips; Keep decals on top; Stops with Colour tick and + Stop; **Add Fade**.
- **Race Wear…**: looks Showroom, Short-Track Oval, Road Course, Dirt Late Model, Endurance 24 h; Laps (or hours) and Strength 0-100.
- Buyer words: "put my number on both doors and the roof" = Number Kit; "my logo on the hood and both quarters in chrome" = Sponsor Kit; "do the whole league" = League Pack; "fade from red at the nose to black at the tail" = Car-Space Fade; "centre stripe" = Car Stripe; "make it look raced" = Race Wear.

## Shokk Drop
- The header **Shokk Drop** button opens a page for importing art. New drop Type: Paint finish (image becomes the colour, a matching spec is built), Pattern (repeating design, keeps transparency), Spec overlay (shine only; R metallic, G roughness, B clearcoat), Paint + spec maps (exact) (your own spec used as given) and Car template (whole car) (a full-body paint and spec that drops over the car as one zone).
- Spec channel strength M / R / CC is set 0-200% each (default 100%) when you bring your own spec plate. DNA Remix blends two spec styles; Spec wildness sets how loud the shine gets; ⚡ SHOKK THE WORLD makes 20 spec variations to keep favourites from. Drops appear in the SHOKK DROP group in the booth and can be shared as .spbdrop packs.
- Buyer words: "use my own spec maps" = Paint + spec maps (exact); "turn this picture into a pattern" = Pattern.

## MCP side
- spb_kit (if available): kit sponsor / number place and remove, kit spec check (Spec Doctor), fix, propose (Auto Spec proposal) and apply. Use only when the buyer asks in words, pass their words, and relay the numbers it returns. A flat picture gets a refusal.
- spb_edit_layer, spb_get_car_map and spb_status cover layers; spb_undo undoes; spb_tweak adjusts one property of the zone you are working on; spb_add_graphic draws a graphic; spb_preview and spb_render show the result.

## Buyer words and which tool
- "undo that" / "put it back": spb_undo or Ctrl+Z.
- "paint both sides the same": Mirror Paint or Mirror To Other Side.
- "make this part glossier / duller": spb_refinish look, or Spec Brush.
- "check it will look right in iRacing": Spec Doctor and Flake Studio Sim-Safe.
