# Glossary: buyer and painter words, and what the app does with them

## Core facts
- "Crushed", "tighter", "finer" and "smaller pattern" all mean the pattern Scale gets smaller (more repeats), while "bigger", "blown up" and "larger" mean Scale goes up; "crushed" is never a finish and never "brushed", and "crush the pattern to 50%" means Scale 50%, shown as 0.50x.
- Shine words map onto the iRacing spec map, where R = metallic, G = roughness (0 = mirror) and B = clearcoat (0-15 = none, 16 = maximum gloss, rising toward 255 = duller); the sliders for them are named R Metal, G Rough and B Coat.
- Four kinds of look exist: a Base is a material that always supplies the spec (Foundation bases keep your paint colour), a Special is a complete look that brings its own colours, a Pattern is a visible shape layer, and a spec pattern is texture in the spec map only.
- Part words resolve to eight named parts (left side, right side, hood, roof, trunk, spoiler, front bumper, rear bumper); door, fender and quarter panel sit on a side, and "the back", "the front" or "the top" alone are ambiguous.
- Painter phrases with no exact finish name (for example "colour flop" or "baked enamel") are still understood: the app reads them as plain look words (for example "colour flop" as a chameleon colour shift).

## Contents
1. Scale and size words
2. Shine and finish words
3. Spec map words and sliders
4. Sparkle, flake and colour-shift words
5. Part and position words
6. Layout words
7. App words: base, special, pattern, zone
8. Painter phrases the app understands
9. Words that mislead

## 1. Scale and size words
- Crushed, crushed down, crushed to 30%, tighter, finer, smaller pattern: Scale smaller. Crushed to 30% is a Scale of 0.3; bigger, blown up and larger are Scale up.
- The pattern Scale slider runs from 10% to 400% and starts at 1.00x. Smaller values mean more repetitions, larger values mean zoomed in. The Base Scale slider runs from 0.05x to 5.0x with 1.00x at the centre and tiles the base material texture inside the zone.
- With spb_tweak, scale is the size of a pattern or texture (direction down means smaller or finer), opacity is pattern strength and intensity is finish strength. Opacity (0-100%) is how visible a pattern is; Strength (0-100%) is how much of its effect lands in paint and spec.
- Shine-only finishes (carbon, chrome, matte) show no texture size or shine in the flat preview, so a size change on them looks like nothing; check the spec preview instead.
- "Crushed" must never be read as "brushed": brushed is a metal finish with a fine parallel grain.

## 2. Shine and finish words
- Numbers are metal / roughness / clearcoat. Gloss 0 / 30 / 16: standard shiny paint under clearcoat, the safe default under numbers and sponsors. Wet Look 0 / 15 / 16: gloss with a very thick, smooth clearcoat feel and deep, liquid reflections. Semi-Gloss 0 / 55 / 40.
- Satin 0 / 95 / 70: a low sheen between gloss and matte with soft highlights. Matte 0 / 200 / 160: no clearcoat shine, so no sharp reflections. Synonyms the design library reads: eggshell and semi gloss for satin; flat, flatter, duller and dead flat for matte; shiny, shinier, wet paint and high gloss for gloss.
- Metallic 200 / 50 / 16: paint with fine aluminium flake that sparkles in sun. Pearl 100 / 40 / 16: tiny pearlescent (mica) particles, a soft shimmer and a slight colour shift with angle. Candy 200 / 15 / 16: a translucent, strongly tinted coat over a bright metallic base, deep and saturated.
- Chrome 255 / 2 / 16: a mirror metal surface that reflects everything around it, loud on big areas and great on trim. Satin Chrome 250 / 45 / 40: still bright metal with soft reflections (brushed chrome and soft chrome mean this). Dark Chrome 250 / 15 / 40: mirror metal tinted dark (black chrome and smoked chrome mean this).
- Brushed 180 / 75 / 65: fine parallel grain that reads as raw metal with streaky highlights. Frozen 160 / 85 / 130: a frosted, hazed metal that is cold and dry. Matte Metallic 225 / 140 / 100: metal that does not shine. Gunmetal 220 / 40 / 16: dark blue-grey metallic.
- Cerakote 40 / 130 / 160: a thin ceramic coating, flat, tough and slightly metallic. Powder Coat 10 / 120 / 145: a baked powder finish, thick, even and semi-matte. Vinyl wrap: even satin colour with little depth. Carbon fibre: the woven carbon pattern under clearcoat, a technical race-car texture.
- Clearcoat: in the spec map the B value runs from 16 (maximum gloss) up to 255 (dull), and 0-15 means no clearcoat. "Full clearcoat" means 16, never 255.

## 3. Spec map words and sliders
- Spec map: the map of how a surface reflects (metal, shine, roughness, clearcoat). R = metallic, G = roughness, B = clearcoat, A = specular mask (rarely used, advanced).
- R Metal, G Rough and B Coat are zone sliders from -127 to +127 that shift each channel. More metal makes the body colour jump through harder; lower rough gives sharp mirror flashes and higher rough a soft satin glow; on B Coat minus is glossier and wetter (it stops at 16) and plus is duller and flatter (up to 255).
- "Reflective" means low roughness plus high metal. "Worn" means roughness up and clearcoat down.
- Auto-Pop is a button on the spec sliders: it reads the zone's current spec and nudges it toward gloss (more metal flash, less rough, glassier clearcoat) as a starting point, and one Undo reverts it.
- In the spec preview, red is metal, teal is matte and rough, black is plain gloss, and pink or white speckle is flake or sparkle.
- Spec-only change ("keep the colours", "only the shine"): the Base Color option "Use source paint (spec only)", or a shine-family finish on a zone with no colour.

## 4. Sparkle, flake and colour-shift words
- Flake: tiny bright metal specks. Metalflake, microflake and flake bomb are read as metallic flake, fine flake and dense flake glitter. Glitter breaks up digit edges at speed, so keep it off numbers.
- Holographic: rainbow-shifting specks or bands. Prizm, iridescent and chameleon are colour-shifting looks; "colour flop" and "colour travel" are read as an iridescent chameleon shift.
- Pearl is the subtle colour shift; Specials in the finish library are where the stronger colour shifts, prizm and micro-flake live.
- Color Flip (a zone dial): the paint's dark structure rotates to a second hue, like an angle-shift chameleon paint; 0 degrees is off. Color Depth is candy-coat depth: low is a thin translucent glaze and high is deep wet candy (0% is no colour, 15% a glaze, 65% rich, 100% the deepest candy). Underglow lets a metal ground coat shine through the colour, gold under warm colours and silver under cool ones. They stay greyed out until a colour is picked.
- Pop: a difference in shine or colour with whatever sits next to it. Premium: one real material or one rich colour coat. Shimmer: fine, in one place. Deep: a thick, clear-looking surface.

## 5. Part and position words
- Hood is also bonnet. Trunk is also deck lid, boot lid or rear deck. Spoiler is also wing or top wing. Front bumper is also splitter, front lip, air dam, nose, front fascia or front end. Rear bumper is also diffuser, rear fascia or rear end.
- Door, fender and quarter panel are on a side: "left door" means the left side, "the sides" means left side plus right side, and the driver's side reads as the left side and the passenger's side as the right side. Cab means roof plus left side plus right side.
- Roof-line: the top edge of the side panels, position 0. Rocker: the bottom edge, position 1. Belt or beltline: a stripe just under the roof-line, about 0.12 to 0.22. Lower body: 0.68 to 1.0. Length runs 0 at the front to 1 at the rear.
- Sill band: a colour band along the bottom of both sides. Rear quarter: the rear 24% of the sides. Front fender: the front 22%.
- Sponsors means logos and decals. Numbers, sponsors and logos are protected by default and change only when named.

## 6. Layout words
- Livery or scheme: the whole layout of body colour plus bands, stripes and block colours. A named classic livery is colours and stripe layout only, with no logos or lettering.
- Two-tone: body colour above, a second colour from the belt down plus hood and bumpers. Lower band: a colour band along the lower body. Colour block: big blocks on hood, roof and quarters.
- Pinstripe: a thin line along both sides. Pinline: a thin line on the seam between two colours. Outline: a line around a part, layer, element or zone edge. Racing stripes and bands: stripe. Centre stripe: down the middle of hood, roof and trunk.
- Gradient or fade: two or more colours blending; "clear" as a stop fades into the paint underneath. "Flip it" after a gradient reverses its stops.
- Accent or trim with no shape named: the app always asks for a thin outline or a band across it, and never guesses.

## 7. App words: base, special, pattern, zone
- Base: the material that always supplies the spec map (metal, roughness, clearcoat). Base Color decides where the colour comes from: "Use finish's own color", "Use source paint (spec only)", "Use solid color", "From special" or "Custom gradient".
- Special: a complete look that brings its own colours and texture (use colour "finish"; a solid colour would replace its palette). Pattern: visible shapes. Spec pattern: texture in the spec map only (flake, holographic, weave and similar). The finish library tabs are Bases, Patterns and Specials, with browse modes Quick Start, Materials, Specials, Surface, All and Adv.
- Zone: which pixels get which look. The top zone in the list (position 1) wins where zones overlap. The catch-all zone is named Everything Else and catches unclaimed pixels; Reset All Zones returns to the default five (Zone 1 to 4 plus Everything Else), and Undo brings the old setup back.
- A zone card has the sections BASE, COLOR, PATTERN and OVERLAYS. OVERLAYS stack additional base finishes on top of the primary base, each with its own pattern, blend mode and opacity.
- Foundation finish: a base used with the source paint so only the spec changes. The catalogue holds about 4,800 looks.

## 8. Painter phrases the app understands
- Baked enamel, coachwork gloss: smooth gloss. Silk matte, low luster, muted sheen, egg shell: satin. Mat finish: matte flat paint. Pearl dust: fine pearl shimmer. Tinted chrome: coloured reflective chrome.
- Carbon fibre, 2x2 twill: carbon weave. Plain weave and ripstop fabric: woven grid. Wood grain and woodgrain: wood grain lines. Burr walnut: brown wood swirl. Marbling: marble swirl veins.
- Spun aluminum and concentric machining: circular machined grooves. Hammer finish: hammered dimpled metal. Shot blasted: blasted rough metal. Polished billet: machined polished aluminium. Punch plate: holes in metal plate.
- Burnt titanium and exhaust blueing: heat-blued metal. Rust bloom: orange rust spots. Weather beaten and scuffed paint: worn, scratched paint. Ratrod: worn, rusty, matte. Kustom: candy gloss retro.
- Old school: classic retro paint. Period correct: classic clean paint. Cyber punk: cyber neon circuit. Hud grid and wireframe grid: technical grid. 8-bit and pixelated: pixel digital retro. Retrowave: neon grid retro.

## 9. Words that mislead
- "Brighter" with nothing earlier can mean a lighter colour or a shinier finish: ask which.
- "Accent", "trim" and "pop" are not shapes or finishes by themselves; each needs a part and a look.
- Windows, glass, wheels, rims, tyres, lights, lenses, interior, helmet, suit, exhaust and roll cage are not on the paint sheet.
- "Make it chrome" on a coloured part: shine-only chrome keeps the colour as a tinted chrome, but the sim multiplies the colour by full metal, so a normal colour goes dark; silver chrome needs a white or near-white part. Say which you did; Metallic, Pearl, Satin Chrome and Brushed keep a coloured part readable.
- Complaint words such as boring, dull, flat, washed out, plastic or cheap are complaints to answer, not orders.
