# Design playbook: how to suggest well

## Core facts
- A look pops because of a difference in shine or in colour with whatever sits next to it, so judge a part by its neighbours and change one axis at a time.
- Make the spec the opposite of the paint: matte beside gloss, metal beside non-metal, a warm matte beside a cool metal.
- Offer 2-3 concrete options, each naming colour(s), one named part and a finish; never paint a whole scheme unasked, and change only the parts the buyer named.
- After acting, say what you chose and offer 1-2 alternatives, render once per finished request, and check the result with spb_check or spb_preview before claiming success.

## Contents
1. Contrast: what makes a look pop
2. The spec as the opposite of the paint
3. Metal, chrome and the sim
4. Offering 2-3 options
5. Asking the app for finish ideas
6. Scheme presets
7. Elements and proportions
8. Palettes and composition
9. Named classic liveries
10. Proven recipes in buyer words
11. Restraint
12. After acting

## 1. Contrast: what makes a look pop
- The app's own rule: pop usually comes from a difference in shine or colour with whatever is next to it. Check what touches the part, then change one axis: light against dark, warm against cool, gloss against flat.
- Calm body plus one loud accent works: one loud accent colour on the stripes or bumpers against a calm body, or a brighter body colour with dark contrast trim.
- An accent close to the body colour barely shows. Pick an accent clearly different in lightness or hue; the design library swaps in a stronger colour on its own when an accent is too close.
- Thin accents (pinstripes, trim lines) read at a glance only with a different shine or a metal edge.
- Keep the middle of the sides (height 0.3 to 0.65, where the number sits) calm: busy art there kills readability.
- Two colours that are nearly the same barely show against each other; the app flags this and asks for a contrasting colour.

## 2. The spec as the opposite of the paint
- iRacing spec map: R = metallic, G = roughness (0 = mirror), B = clearcoat (0-15 = none, 16 = maximum gloss, rising toward 255 = duller). The app's sliders for them are R Metal, G Rough and B Coat.
- Pop recipe: a warm matte next to a cool metal, opposite colour AND opposite shine.
- Gloss accents on a flat body, or satin or matte accents on a glossy body, make a deliberate two-tone: the same colour with a different shine still separates.
- Finish values, in the order metal / roughness / clearcoat: Gloss 0 / 30 / 16, Wet Look 0 / 15 / 16, Satin 0 / 95 / 70, Matte 0 / 200 / 160, Metallic 200 / 50 / 16, Pearl 100 / 40 / 16, Candy 200 / 15 / 16, Brushed 180 / 75 / 65, Chrome 255 / 2 / 16.
- Spec-only changes (the buyer says "only the shine", "keep the colours"): use the shine family on the zones that already cover the area, with no colour, so the paint stays identical.

## 3. Metal, chrome and the sim
- In the sim, iRacing multiplies the paint colour by the metal level, so any normal colour turned fully metallic goes dark. A chrome part has to be painted white or nearly white.
- Partial-metal finishes keep their colour: Metallic, Pearl, Satin Chrome, Brushed and Anodized. Prefer them on a coloured stripe; full chrome on a coloured stripe can go dark.
- Chrome is loud on big areas and best on trim and thin accents. Candy gives depth you can see into and is best on a strong, single colour.
- Avoid chrome, glitter and colour-shifting finishes on numbers: they break up the digit edges at speed. Numbers read by colour contrast, not finish; plain gloss gives the cleanest edges and matte removes glare.

## 4. Offering 2-3 options
- Write each option as colour(s) + named part + finish, for example "white body with a gold pinstripe on both sides, satin" or "matte black roof against a gloss red body".
- Pop options the app itself offers: one loud accent on the stripes or bumpers against a calm body; chrome or candy trim on the accents for shine contrast; a brighter body with dark contrast trim.
- "Looks plastic" options: metal flake under the clearcoat on the body (shine only, colours stay); a pearl body with gloss stripes (shine only); a satin body with gloss trim so the shapes read (shine only).
- "Numbers are hard to read" options: a thick contrasting outline around the numbers; recolour the numbers to contrast with the body behind them; calm the body colour behind the numbers.
- After the options, stop. Act when the buyer picks one, or says "surprise me" or "just do it".

## 5. Asking the app for finish ideas
- spb_suggest_finishes ranks the whole catalogue (about 4,800 looks) for this car. Pass part, goal (pop, premium, shimmer, deep, retro, stealth, readable or subtle), ask (the buyer's own words, whole sentence), and novelty (safe, balanced or wild).
- The option that picks keep, complete or texture narrows the answer: keep = shine only and the colours stay; complete = a whole look that brings its own palette and replaces the colour; texture = a pattern layer on top.
- Each row has a look, a reason, loud and busy scores from 1 to 5, a pair and an avoid note. Offer 3-5 with the reason in one line each, taken from the row; never invent properties.
- For more options pass the keys already shown in exclude. To say "like X but calmer", pass the finish as like and add a change word (calm, bold, darker, lighter, glossier, flatter, sparklier, smoother, warmer, cooler, finer, coarser). Negations ("no glitter", "anything but chrome") are honoured; keep passing them for the rest of the chat.
- The pop goal favours metal, depth and gloss (candy, pearl, Wet Look, chrome, flake) and ranks flat finishes lower, so use matte as the calm partner beside a pop finish rather than as the pop itself.
- Goal rules of thumb: premium is mostly restraint, one real material or one rich colour coat; shimmer looks expensive when it is fine and in one place; colour looks deeper when the surface looks thick and clear (candy, Wet Look, pearl, and a perfect gloss on dark paint); stealth kills reflections (matte, matte metallic, dark chrome accents).

## 6. Scheme presets
- Call spb_design_recipes first; it returns presets, elements, proportions, palettes and named liveries. Then spb_apply_scheme builds the scheme in one call, base colour first, later pieces stacked above it.
- Retro lower band: body colour on top, a bold band along the lower body with a thin trim line above it, matching bumpers and spoiler, a second accent on the beltline.
- Classic twin stripes: two parallel stripes nose to tail on the sides, continuing as a centre stripe over hood, roof and trunk (the 70s-80s racing look).
- Two-tone: body colour above, a second colour from the belt down plus hood and bumpers.
- Colour block: hood, roof and rear quarters in different colours, bumpers in the accent.
- Bookends: contrasting front and rear ends (bumpers and spoiler) with a thin rocker stripe.
- Stealth: dark on dark, a slightly different dark roof, hood and bumpers, one thin accent line.
- Solid colour: one colour over the whole body; numbers, sponsors and logos stay. It is the base for graphics and finishes added after it.
- Use confirm only when the buyer asked for a full livery with colours, approved your proposal, or said "surprise me" or "just do it". Otherwise offer 2-3 options and wait. The body colour replaces only the car's main body colour; accent art already on the car stays.

## 7. Elements and proportions
- Stripe and band positions are fractions measured down from the roof-line (0) to the rocker (1): beltline 0.10 to 0.25, door centre 0.35 to 0.65, lower body 0.68 to 1.0. Along the length, 0 is the front and 1 is the rear.
- Elements for spb_apply_scheme: base, lower band (default 0.68 to 1.0), upper band (0 to 0.22), pinstripe (default 0.64, width 0.03), beltline stripe (0.12 to 0.22), twin stripes (centred at 0.5, each 0.07 wide, 0.03 gap), side stripe (any from and to), rear quarter (rear 24%), front fender (front 22%), hood, roof, trunk, spoiler, bumpers (front and rear), centre stripe (down the middle of hood, roof and trunk, width 0.14, optional thin trim lines beside it).
- Drawn graphics come from spb_add_graphic: rings, speed lines, stripes at any angle, waves, chevrons, checker, dots, rays, lightning and flames. Flame styles are hotrod, tribal, ghost and truefire; use length 0.9 or more on the long sides.
- Always place on named parts: left side, right side, hood, roof, trunk, spoiler, front bumper, rear bumper. Never use big grid boxes.

## 8. Palettes and composition
- A palette has five roles: base (body colour), a (main accent), b (second accent), c (third) and trim (pinstripe or trim colour). Adjust the colours to the buyer's words.
- Palettes exist for eras (50s mint diner, 70s earth, 80s neon, 90s teal, modern stealth), brands and teams, countries, sports colours and moods (fire, ice, forest, Halloween, Christmas, sunset, ocean, desert, galaxy, toxic, rose gold, patina, pastel, bubblegum, aggressive). Ask spb_design_recipes with a query such as "70s" or "stealth" and take the palette id from the result.
- Composition rules from the library: one dominant colour (about 60%), one strong accent (about 30%), one trim colour (about 10%); white or black as the quiet colour lets the accents sing; line up colour blocks across the car (the side band continues in the bumpers, the hood stripe continues over roof and trunk); flat paint with chrome trim lines is the modern retro look and gloss everywhere is the showroom look; never cover the numbers or sponsor panels.

## 9. Named classic liveries
- A named classic livery is a concrete order: call spb_design_recipes, then spb_apply_scheme with confirm at once, and never ask which layout. They are colours and stripe layout only, no logos or lettering.
- Available: Gulf, Martini, John Player Special (JPS), Rothmans, Marlboro, Castrol, Monster Energy-style, Sunoco, Mobil 1-style, Valvoline, Pennzoil-style, STP-style, Hooters-style, Kodak-style, Tide-style, Rockstar-style, Red Bull-style, Pepsi-style, Cola-red, Ferrari-style, McLaren papaya, British racing green, Police-style, Taxi-style, Silver Arrow, FedEx-style, Mountain Dew-style, John Deere-style and UPS-style.
- Examples of the layouts: Gulf is a powder blue body with a wide orange centre stripe edged in navy over hood, roof and trunk, repeated along both sides; Martini is a white body with a navy, light blue and red three-stripe set along the sides and over hood, roof and trunk; JPS is a black body with gold pinlines and a gold stripe.
- After applying, say what you chose and offer two alternatives: another take (same colours, a different layout) or a different finish (matte or gloss).

## 10. Proven recipes in buyer words
- Mean or aggressive: matte black body with a red hood; dark grey body with carbon fibre roof and hood; black body with red flames on both sides.
- Expensive or premium: pearl white body with a gold roof; gloss black body with a silver roof; deep burgundy body with a gold hood.
- Fast or sporty: red body with a black roof; yellow body with a black hood; black body with red flames on both sides.
- Retro: orange body with a white roof; teal body with a cream roof; yellow body with a black hood.
- Clean or classy: white body with a black roof; silver body with a matte black hood and roof; navy body with a white roof.
- Stealth or moody: matte black body with a dark purple roof; gunmetal grey body with a black hood; dark green body with a black roof.
- Soft or pastel: light pink body with a white roof; baby blue body with a white roof; mint green body with a pale yellow hood.
- Accent for an existing body colour: red, roof white or hood black; black, hood and roof neon green or roof red; white, roof black or hood red; blue, roof orange or roof white; orange, roof black or hood blue; green, roof yellow or hood black.

## 11. Restraint
- The buyer's paint is their work, and most harm comes from acting too soon. A vague, mood, taste or reference request changes nothing: ask one short question or offer 2-3 concrete options and stop.
- Never paint a whole scheme or the whole car unasked. Change only the parts the buyer named: "the right door" means the right side, and a part named as the reference ("same as the left") is not a target.
- Numbers, sponsors and logos stay untouched unless named. Never mute or delete the buyer's zones unless they asked. A whole-car colour change keeps the accent art; recolour an accent only when the buyer names it ("the accents", "everything").
- Keep the buyer's stated colours and the looks they rejected. Pass what they do not want to the finish search and keep passing it.

## 12. After acting
- Say what you chose, then offer 1-2 alternatives. Do not ask which variant before acting on a concrete request.
- Read the measured result of every change. A clean verdict: say what the app's line says. Reported, substituted or no visible change: tell the buyer exactly that, offer undo, and never claim a clean result.
- Iterate on the same zone with spb_tweak, one property at a time: scale, rotation, brightness, hue, saturation, shine, metal, opacity, intensity or colour. "Pattern smaller", "brighter", "change the pink to blue" are all tweaks, not new zones.
- Shine-only finishes (carbon, chrome, matte) show no texture size or shine in the flat preview. Call spb_preview with spec set to true: it adds the spec map (red is metal, teal is matte, black is plain gloss).
- Call spb_render once after the last change of a request that changed the paint, and say the seconds and the files saved; files saved 0 means nothing was written. Never render for advice, complaints or questions.
- When the buyer asks you to verify, call spb_check: it measures what the last change really did on the rendered paint.
