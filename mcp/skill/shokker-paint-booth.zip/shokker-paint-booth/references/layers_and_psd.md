# Layers, layered paint files and flat paints

## Core facts
- A layered paint file (PSD, XCF or ORA) keeps the body paint, numbers, sponsors, tape, decals and guide layers on separate layers, while a flat TGA, PNG or JPEG has no layers and can only be treated as one picture.
- The Layers tab lists every layer with an eye, a name, an opacity percentage and a blend tag, and selecting a row opens Opacity (0-100), Blend, Hue (-180 to 180), Sat (-100 to 100) and Bright (-100 to 200) controls.
- A zone can be tied to chosen layers with the RESTRICT TO LAYERS box, so it paints only where those layers show and is not covered by art above, which is why numbers, sponsors and logos kept on layers above the body paint keep their look when the body finish changes.
- Wire, Mask and Car Mandatory are template guide layers that help the painter but are not paint, and the whole group named "Turn Off Before Exporting TGA" is left out of the rendered car paint.
- With the spb_* tools, spb_get_car_map says what each layer is, spb_edit_layer changes visibility, opacity and blend, and flat paints use spb_look_at_paint, spb_mark_elements, spb_describe_paint and spb_refinish.

## Contents
- Opening a paint: layered or flat
- The Layers tab
- Blend modes and per-layer adjustments
- Layers versus zones
- Why numbers, sponsors and logos sit on top
- Template guide layers
- Spec map layers
- Driving layers with the spb_* tools
- Flat paints: numbers, sponsors and stripes
- Buyer words and what to do

## Opening a paint: layered or flat
- The header Source Paint field takes a path, and two buttons beside it browse for a file: **TGA/PNG/JPEG** for a flat image and **PSD/XCF/ORA** for a layered file with its editable layer tree. The default look also offers an **Open Paint…** menu with both choices.
- The Open Paint… tooltip: a layered PSD, XCF or ORA template keeps every layer; a flat TGA, PNG or JPEG image does not.
- A PSD is a Photoshop document: a stack of named layers and groups. GIMP files (XCF) and Krita files (ORA) open the same way. Sponsor logos, numbers, masks and paint stay separate, so each can be shown, hidden, restyled or restricted on its own.
- A flat TGA shows "NO LAYERS - TGA LOADED" in the Layers tab ("This car is a flat TGA with no layer tree") with a pointer to **Open Layered** for editable layers. Everything on a flat paint is baked into one picture, so the app has to guess where numbers, sponsors and stripes are (see the flat-paint section).
- When nothing is loaded the tab says "No layers yet." and "Click Open Layered above to load a Photoshop, GIMP, or Krita document".
- If a layered file cannot be rebuilt exactly, the tab shows a "SOURCE PAINT PROTECTED" card: the flattened source stays visible and locked, and the original layers remain below as hidden recovery layers.

## The Layers tab
The tab is the LAYERS button in the right panel (next to FINISHES).
- **Top bar:** **Open Layered**, **+ Layer** (a new blank layer on top), an **Actions** menu and a **Filter…** box (filters by layer or group name; Escape clears it).
- **Actions menu:** Place image… (pick a PNG or JPG and place it on a new layer), + Blank layer (a transparent layer to paint on with the Retouch brushes), Flatten document (hidden layers and zone links are shown before removal), Merge visible (Ctrl+Shift+E; hidden layers survive), Photoshop round-trip, Thumbnail size (small / medium / large). Hint line: "Ctrl+click=move · Dbl-click=effects".
- **Row:** eye (click shows or hides; Alt+click isolates the layer or restores), name (double-click renames), group note, **fx** chip when layer effects are on, opacity percentage (drag left or right to scrub), blend tag (KO means Knockout), a gold chip when zones are restricted to the layer, and small buttons for **α** (Alpha Lock: paint only inside existing art), the clipping arrow and the padlock (lock the layer so it cannot be moved or repainted). Group rows have their own eye and click to collapse.
- **Card for the selected layer:** Opacity slider plus a typed percentage box (0-100), Blend list, Hue / Sat / Bright sliders (each with a reset button), and an Overlay row (colour overlay on / off, colour, amount).
- **Card buttons:** DUPE (Shift-click makes a +50 px offset copy for repeated sponsors or numbers), MIRROR (duplicate and flip to the opposite side of the car), STROKE FX (a non-destructive stroke), MERGE ↓, RENAME, EXPORT (save just that layer as a transparent PNG), MAKE ZONE, DELETE, SOLO, FLIP H, FLIP V, ROT 90, MOVE, XFORM (Ctrl+T), PAN, FIT, LOCK ZONE (Ctrl+L) and DONE.
- Ctrl-click toggles a row in the selection and Shift-click selects a range; with two or more rows selected a bar offers MERGE n and DELETE n for the whole selection (DELETE is one undo).

## Blend modes and per-layer adjustments
- Blend list (17 modes: the 16 standard modes plus Knockout): Normal, Multiply, Screen, Overlay, Darken, Lighten, Color Dodge, Color Burn, Hard Light, Soft Light, Difference, Exclusion, Hue, Saturation, Color, Luminosity and "Knockout (punch through)".
- Opacity is 0-100 percent. Hue is -180 to 180 degrees, Sat -100 to 100, Bright -100 to 200 (default 0 for all three). These are non-destructive and save-safe.
- A locked layer greys out its opacity, blend and adjustment controls; unlock it first.
- Buyer words: "fade the stripe to half" = Opacity 50; "darken the shadows layer" = Multiply; "make the glow layer lighten the paint" = Screen; "cut a hole through the paint" = Knockout; "shift the pink layer toward orange" = Hue.

## Layers versus zones
- A **zone** is a finish recipe (base material, pattern, colour, intensity) applied to the pixels it covers. A **layer** is a piece of artwork in the paint file. "Mute or switch off a zone" is about zones; "hide, show, turn off or turn on the tape, the sponsors, the wire, the mask" is about layers.
- In a zone's COLOR section a box named **RESTRICT TO LAYERS** lists every layer with a tick box. Tick one or more layers and the zone paints wherever any ticked layer visibly shows. The status line reads "Restricted to n layers: names" or "All layers (no restriction)". **Clear** removes all ticks.
- Only visible contribution counts: a ticked layer that is hidden does not paint ("Hidden (not painting)" in orange); the zone gets only the pixels where that layer itself is mostly opaque AND not mostly covered by art stacked above it, so covered pixels and faint edge halos are left alone. A "Missing source layer(s)" warning means the layer was deleted or renamed.
- **MAKE ZONE** (layer card) creates a zone already restricted to that layer; give it a base material afterwards. **LOCK ZONE** (Ctrl+L) restricts the active zone to the selected layer. The lower zone number wins where zones overlap.
- With a layer brush in Layer mode and a restricted zone active, a **Clip to <zone name>** tick keeps strokes inside that zone's area (untick it to paint anywhere). Strokes outside the area show a warning instead of painting.
- Buyer words: "make the roof chrome but only on the roof layer" = new zone, tick that layer; "put a pearl on just the numbers" = zone restricted to the numbers layer; "make a zone from this logo" = MAKE ZONE.

## Why numbers, sponsors and logos sit on top
- Number, sponsor and decal art keeps its colours when the body changes: after painting, the app puts that art's colours back from the source paint, so a body finish or a 2nd-5th base overlay cannot wash over it. To change numbers or sponsors on purpose, target them by name (a zone restricted to that layer, or a refinish on numbers / sponsors).
- Finishes are painted by zones, and a zone restricted to the body layer stops where art above it begins. Numbers, sponsor logos and decals kept on layers above the body paint therefore stay as drawn when the body goes from matte to chrome to candy. Put such artwork above the body layer, never under it.
- iRacing can also stamp its own number and sponsors on the car. In the header, **Custom Number** (checked: car files save as car_num_[ID].tga, you run a custom number) and **Sim-Stamped Number** (checked: files save as car_[ID].tga and iRacing stamps the number) are a pair; only one can be ticked.
- A sim-stamped number or sponsor takes on the shine of the paint underneath it. The **Decal Rescue Kit…** (Spec Tools menu) lays a flat, satin or gloss non-metallic spec beneath the stamped areas so they do not turn chrome or glitter with the body.
- Buyer words: "my number turned chrome with the car" = check whether the number is a layer above the body or a sim stamp, then use the Decal Rescue Kit for stamps; "keep the sponsors as they are" = leave the sponsors layer visible above the body layer and name it in the exclude list.

## Template guide layers
- Car templates carry guide layers: **Wire** (panel outlines), **Mask** (what is paintable) and **Car Mandatory**, plus the group **Turn Off Before Exporting TGA** (number and sponsor stamp blocks). They arrive switched on after a PSD loads.
- Judge looks with them off: hide them with their eyes (the in-app helper does it when asked to hide the template layers, and Undo brings them back). The Live Preview already leaves them out, so what it shows is what RENDER writes.
- RENDER, export and season output leave the whole "Turn Off Before Exporting TGA" group out of the car paint whatever its eye state, so iRacing's own number and sponsor stamps are not doubled. The editor still shows what you toggled.
- Never hide the body paint layer to "clean up"; hide only the guides.
- Buyer words: "I can see the wireframe on my car" = hide Wire, Mask and Car Mandatory; "what is that grid" = Wire, a template guide.

## Spec map layers
- Some templates hold layers that are not colour at all but spec maps for metal, roughness or clearcoat (red = metallic, green = roughness, blue = clearcoat; 0-15 blue means no clearcoat, 16 is the strongest coat, rising toward 255 is duller). A template can reuse the name Base Paint for several of them.
- Do not recolour a spec or alpha map layer with paint colour. Ask spb_get_car_map first; it labels each layer body paint, numbers, sponsors, tape, decals or template.

## Driving layers with the spb_* tools
- spb_status lists the layers; use its exact names. spb_get_car_map gives each layer's role and the named car parts. If it reports that parts are not known yet, call spb_request_parts before designing.
- spb_edit_layer takes layer (the exact name from spb_status, written group/layer, or its ID), visible (true / false), opacity (0-100) and blend (a mode from the list above). Template layers are described as off before export; never hide the body paint layer unasked.
- In installs that support it, spb_edit_layer also takes colour (#RRGGBB) and a colour opacity (0-100, default 100) for a whole-layer colour change that keeps the layers above it. Never use it on spec or alpha map layers.
- spb_undo takes back your last changes in the same session.
- Whole-layer colour only: "make the Base layer navy" = spb_edit_layer colour. Anything inside a layer, or a new material, goes through a zone restricted to that layer.

## Flat paints: numbers, sponsors and stripes
- On a flat paint there are no number, sponsor or stripe layers, so the app only guesses. Many flat paints draw no number at all, so never assume one exists: look first.
- **spb_look_at_paint** returns the sheet with a ruler in steps of 0.1 and the app's guess: numbers in pink, sponsors in blue, stripes in yellow. Give region as [x0,y0,x1,y1] fractions or {part: "left side"} for a full-resolution zoom of one area (the guess is off by default for a zoom).
- **spb_describe_paint** says what the paint really shows in painter words: its colours (share, hex, where), the numbers, sponsors and stripes layers, and the looks spb_refinish understands. Call it before changing what the car already shows, and to answer complaints such as "looks plastic".
- **spb_mark_elements** tells the app where things are: kind (numbers, sponsors, stripes), boxes as sheet fractions (each at most about 10% of the sheet, logos 12%), or none:true when there are none. mode: glyph (numbers), logo (sponsors; lettering:true keeps the plate), colour-in-region (stripes; colour = the colour the stripe has now, auto or #rrggbb). replace:false adds to earlier marks. Check the per-box result and the image afterwards.
- **spb_refinish** then changes it: target a colour, numbers, sponsors, stripes, main colour or a part; look (matte, satin, gloss, powder coat, plasti dip, cerakote, chrome, metallic, pearl, candy, brushed, anodized, vinyl wrap...), colour, or glossier / duller. exclude lists what must not change (numbers, sponsors, stripes). Always pass the buyer's own words in the buyer-said field.
- Without marked boxes, a flat paint answers numbers, sponsors or stripes with a needs-confirmation answer: tell the buyer to answer the card and claim nothing meanwhile.
- Order: spb_look_at_paint, say what you see, spb_mark_elements, check, spb_refinish. If the thing is not there, say so.
- Buyer words: "make the numbers gold" on a flat paint = look, mark the number boxes, refinish target numbers; "black matte but leave the sponsors alone" = refinish with exclude sponsors; "recolour the red stripe" = mark it as stripes in colour-in-region mode.

## Buyer words and what to do
- "Show the tape layer" / "hide the sponsors": spb_edit_layer visible.
- "Fade the decals to 60%": spb_edit_layer opacity 60.
- "Which layer is my number on": spb_get_car_map, then name it.
- "Only the pink on the Numbers layer": spb_refinish with layer set to that layer.
- "Everything except the numbers": exclude numbers, or a zone restricted to the body layer.
- "Why did my number change when I changed the body": the number was under the body or baked into a flat paint; move it above the body layer or mark it and use exclude.
