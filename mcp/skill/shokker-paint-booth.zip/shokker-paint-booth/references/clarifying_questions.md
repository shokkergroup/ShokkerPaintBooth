# Clarifying questions: when to ask, when to act

## Core facts
- Ask exactly one short question (or offer 2-3 concrete options) only when the request is vague (no colour, finish or place named), a mood or taste word, or a reference to a real car, country or brand look whose colours would be a guess; then change nothing and wait.
- A concrete request names a part (or the car) plus a colour, shade, finish family, effect, pattern idea or a named classic livery, and must be done now, including terse or misspelt orders such as "hod to chrom" or "mak teh roof blak".
- A complaint gets an answer in a sentence or two plus 1-3 fixes and then you wait; a how-to or "can I" question gets an answer (from this skill's references first, spb_encyclopedia for anything they do not cover) and changes nothing.
- Never ask the same thing twice: act on the buyer's answer with sensible defaults, and treat "surprise me", "just do it" and "you pick" as permission to act.
- The app reads the buyer's words on every write: vague, complaint or question words, and a whole-car change without confirm, come back with options and change nothing, so put that to the buyer and stop.

## Contents
1. The decision at a glance
2. Concrete requests: do them now
3. Vague, mood, taste and reference requests: one question
4. Wording a good question
5. Questions the app asks itself
6. Complaints
7. Questions, how-to and advice-only
8. Render, iRacing and file trouble
9. Never ask twice, and "surprise me"
10. Classified examples

## 1. The decision at a glance
- Concrete (part or car + colour, finish, effect, pattern or named livery): act now, say what you chose, offer 1-2 alternatives afterwards.
- Vague, mood, taste or reference: change nothing; ask one short question or offer 2-3 options (colours + where + finish), then stop.
- Complaint ("looks plastic"): answer in a sentence or two, offer 1-3 fixes, wait.
- Question or how-to (how, can I, what, why, do I need): answer from this skill's references (spb_encyclopedia for anything they do not cover), change nothing.
- Render, iRacing or file trouble: call spb_check_setup and spb_encyclopedia, answer, do not repaint.
- The buyer hands you the choice ("surprise me", "just do it", "go crazy", "you pick"): act now and say what you chose.
- Short correction of your last change ("a bit darker", "again", "less"): act on that change.

## 2. Concrete requests: do them now
- Concrete examples: "holo roof", "dark roof", "mud on the lower doors", "tribal on both fenders", "Martini livery", "candy red roof", "gold pinstripe on both sides".
- Choose the closest catalogue match or the hex yourself, say what you chose, and offer 1-2 alternatives after acting. Never ask which variant.
- Terse, slangy or misspelt orders are concrete too: "hod to chrom", "bumpr red", "roof 2 tone black n gold", "mak teh roof blak". Do them. A misspelt colour, part or finish is never a reason to ask; only a real question (how, can I, what, why, do I need) is a how-to.
- An effect becomes concrete once a place is named: "mud on the lower doors" is an order, while "mud on the bottom" or "make it look dirty" has no single look, no named part and no strength, so ask which look, where and how strong.
- Two candidates (for example two logos): use the most prominent one and say which.
- A whole-car recolour such as "make the car purple" is concrete: recolour the body with confirm set, which keeps the accent art. Set confirm only when the buyer's words name the whole-car change (colours or finish, or a named livery such as Gulf or Martini), they approved your proposal, or they said surprise me.
- A named classic livery is the request itself: look it up with spb_design_recipes and apply it at once; never ask the buyer to pick a layout.
- Follow-ups on your own last change: "a bit darker, lighter, more X, less X" means a new colour clearly different from the old one (about 15-20% lightness or a visibly different hue), never a tiny nudge. "Undo", "take it back" or "back to how it was" is spb_undo, never a hand-set colour.
- Very short follow-ups right after a change ("smaller", "a bit less", "again", "nah too bright") are corrections of that change, not new vague requests.

## 3. Vague, mood, taste and reference requests: one question
- Vague or mood examples: "make it pop", "pastel livery", "make it look fast", "something kind", "something nobody has seen", "make the car look good", "a classy livery", "make it look expensive".
- Reference examples: "like the car that won Daytona", "Brazil colours", "an Italian colours look", "a patriotic look". The colours and layout would be a guess.
- A whole livery or redesign with no colours named is vague too: offer 2-3 schemes with colours.
- A greeting with a wish ("hello, can you help me paint my car") gets one question about what they want. A bare hello or thanks needs no action.
- The app's standard options for a reference ask: "Tell me the 2-3 main colours and where they go (body, stripes, bumpers)"; a layout you propose with those colours (for example white body, colour band low on the sides, colour bumpers) for them to approve; or only the colours, keeping their current layout.
- Standard options for an effect with no place (dirt, mud, rust, worn): a dirt or mud texture low on the sides and bumpers only; a light weathered spec (dull, rough) on the lower body with the colours staying; or leave it clean.
- Ambiguous words with nothing earlier to point at: "make it brighter" (a lighter colour or a shinier finish?), a bare "red" or "chrome" (which part?), "make the roof" (what colour?), "too shiny" with no new finish named (which finish?).

## 4. Wording a good question
- One question, short, with 2-3 concrete options that each name colour(s), a part and a finish. Example: "Which of these? A) white body, gold pinstripe on both sides, satin. B) matte black roof against a gloss red body. C) tell me your own colours."
- Use the buyer's words back to them and keep the options mutually different (a light touch on one part, the full change, something else).
- Do not ask several questions at once, do not ask for information you can read yourself (spb_status, spb_get_car_map and spb_describe_paint tell you the parts, layers and colours), and do not ask which variant of a concrete request.
- If a part the buyer names is not listed for this car, or a tool answers that the part is unknown, do not guess and paint. Ask: "I can't tell where the <part> is on this template. Send me a picture with it circled, or tell me roughly where it is on the sheet (top middle, lower left...)." Then place it with their answer and say which area you used.
- When the car's key parts are missing, call spb_request_parts, tell the buyer to show the parts, and check again.

## 5. Questions the app asks itself
- When a tool returns one of these questions, nothing changed: relay it in plain words and wait for the answer.
- A silver, gold or similar accent with no shape named: "a thin line around its edge, or a band across it?" The app asks this every time; never guess the shape.
- "Which finish should that be (for example gloss, satin, matte, chrome or metallic)?"
- "What colour should the stripe be?", "What colour should the line around the part be?", "What colour should the pinline be?", "Which two colours for the fade?" and "Which colour for the part?"
- "Where should that go?" when no part was named, and "This car has no <part> on its paint map. Which part did you mean?" for a missing part.
- "Which layer is the <thing> on?" when an object that is not a part sits in more than one layer.
- "What should the part become (a colour, a finish or a pattern)?" when a change names no look.

## 6. Complaints
- Examples: "looks plastic", "numbers are hard to read", "looks off", "the stripes look boring", "it looks too shiny".
- Answer in a sentence or two using facts (spb_describe_paint gives the colours and layers in painter words), offer 1-3 fixes, ask which one, and stop. Apply only after the buyer picks.
- A complaint with the fix inside it ("too bright, tone it down", "darker") is a change request. A complaint that the app broke something ("you trashed my numbers") gets an explanation and an offer to undo; undo only if the buyer asks.

## 7. Questions, how-to and advice-only
- Questions: "can I paint the windows?", "how do I export to iRacing?", "what is clearcoat?", "do I need a spec map?". Answer from these references with the real labels and numbers (spb_encyclopedia for anything they do not cover), change nothing, and offer the change afterwards.
- Not on the paint sheet, so answer and never edit: wheels, rims, tyres, windows, glass, window frames, lights, lenses, interior, helmet, suit, exhaust and roll cage. Also impossible by paint: real 3D bumps, dents, embossing, anything physical or moving.
- Advice-only words ("advice only", "just discuss", "don't apply", "nothing applied yet") and plain design questions ("would matte black and satin gold work here", "which looks better") are questions: answer in words and change nothing.
- "Show me gold options" or "what are my options" is a list request: search the catalogue and show choices without changing the car.
- A keep-only sentence ("the hood stays black", "never touch the Logos layer") changes nothing.
- Two options to compare ("show me the roof as carbon and brushed metal") are answered side by side, not painted.

## 8. Render, iRacing and file trouble
- Examples: "my render is not in iRacing", "the paint looks different in the sim", "the preview is slow", "the files are missing".
- Call spb_check_setup first: it reads the user ID, number mode, car folder, the files in it, which template layers are on and the render state. Use spb_encyclopedia for the how-to part. Answer and do not repaint.

## 9. Never ask twice, and "surprise me"
- When the buyer answers your question (a place, a colour, "yes", "less", "the second one"), act on it with sensible defaults. Never ask a second time.
- "Surprise me", "just do it", "go crazy", "do something cool", "pick for me", "I am lost", "your call" mean the choice is yours: act now with confirm, state what you chose and offer alternatives after. If the app still returns options, tell the buyer in one line and offer your top pick as a single yes or no.
- Pass the buyer's latest message word for word in the verbatim-words field of every write tool. Never add your own words, a proposal or "approved" to it; the app checks the frame you send against those words.

## 10. Classified examples
- "make it pop" is vague: offer a loud accent on the stripes or bumpers against a calm body, chrome or candy trim for shine contrast, or a brighter body with dark trim, then stop.
- "pastel livery" is vague: offer two or three pastel schemes (for example light pink body with a white roof) and wait.
- "Brazil colours" is a reference: ask for the 2-3 main colours and where they go, or propose a layout for approval.
- "make it look expensive" is vague: offer a pearl white body with a gold roof, a gloss black body with a silver roof, or a deep burgundy body with a gold hood.
- "hod to chrom" is concrete: make the hood chrome now, say you read it as hood to chrome, and offer a satin chrome alternative.
- "roof 2 tone black n gold" is concrete: do the roof in black and gold, then offer one alternative.
- "mud on the lower doors" is concrete; "mud on the bottom" is vague (which look, where, how strong).
- "holo roof" is concrete: search the catalogue for a holographic look, apply the closest, say which.
- "Martini livery" is a named livery: apply it at once and offer another take.
- "make the car purple" is a whole-car recolour: do it with confirm and keep the accent art.
- "looks plastic" is a complaint: answer, offer a metal flake body, a pearl body with gloss stripes, or satin with gloss trim, and wait.
- "numbers are hard to read" is a complaint: offer a thick outline, a contrasting number colour, or a calmer body behind them.
- "can I paint the windows?" is a question: answer from the encyclopedia (windows are not on the paint sheet) and change nothing.
- "my render is not in iRacing" is trouble: run spb_check_setup and answer.
- "a bit darker" right after a change is a correction: recolour the same part with a clearly darker colour.
