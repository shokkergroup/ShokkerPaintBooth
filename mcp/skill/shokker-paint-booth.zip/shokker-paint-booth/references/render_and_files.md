# Render and files

## Core facts
- RENDER builds the final paint and spec and, when an iRacing Car Folder is set, copies two files into it: car_num_[ID].tga (Custom Number) or car_[ID].tga (Sim-Stamped Number) for the paint, and car_spec_[ID].tga for shine, metal and chrome.
- Three header settings decide whether iRacing finds the files: iRacing User ID (the 4-7 digit Customer ID, not the car number), the number mode (Custom Number or Sim-Stamped Number) and iRacing Car Folder (the driven car's own folder inside Documents\iRacing\paint).
- After a render, Alt+Tab to iRacing and press Ctrl+R (Reload Car Textures); inside Shokker, Ctrl+R means RENDER.
- A green "Saved!" bar means files were written to the car folder; an amber "No iRacing folder set" bar means nothing reached iRacing.
- For Claude, spb_render presses the same RENDER button once a buyer request is finished, and spb_check_setup is the first call whenever a paint will not render, is missing in iRacing or looks different in the sim.

## Contents
- What RENDER writes
- The header settings
- Where the files go
- After the render: the Saved bar and the render card
- Loading the paint in iRacing
- spb_render
- spb_check_setup
- Common file trouble and fixes
- Trading Paints and other drivers

## What RENDER writes
- Paint file: car_num_[ID].tga when Custom Number is ticked, car_[ID].tga when Sim-Stamped Number is ticked. Only one of the two is written per render.
- Spec file: car_spec_[ID].tga, always, whichever number mode is used. Its channels are red = metal, green = roughness, blue = clearcoat, alpha = lighting mask.
- [ID] is the iRacing User ID typed in the header. Without a valid ID (4 to 7 digits) RENDER refuses to start, because iRacing ties a paint to a driver by that number in the file name.
- Size: the render is made at the size of the opened template. iRacing accepts only exactly 2048x2048 or 1024x1024 and silently shows the paint-shop colours for any other size, so open the car's own template and never resize the canvas.
- Format: the paint is saved as a 24-bit TGA and the spec as a 32-bit TGA. Only cars with paintable glass need a 32-bit paint TGA with the template's glass alpha filled.
- iRacing reads only the paint TGA, the spec TGA and the .mip it compiles from the spec; any other image in a render folder is not something iRacing loads.
- Logos and sponsor art placed in Shokker are part of the paint file; no separate decal or team files are written. Helmets and suits are not supported targets: Shokker paints cars.
- Template guide layers (Wire, Mask, Car Mandatory and the number and sponsor stamp blocks, all in the group Turn Off Before Exporting TGA) are left out of the paint automatically, so iRacing's own number and sponsor stamps are not doubled. The Saved bar notes this as "Guide layers (...) left out of the render."
- The first time a render replaces a file that already sits in the car folder, Shokker keeps a copy of the old file with ORIGINAL at the start of its name.
- A render takes seconds to about a minute (more zones, big masks and heavy finishes take longer) and gives up after 5 minutes.

## The header settings
- iRacing User ID: the field is labelled "iRacing User ID" with the placeholder "Customer ID". Its tooltip: in iRacing click the helmet icon (top right), then Profile; this is not your car number. RENDER shows the toast "Enter your iRacing User ID (4-7 digits) in the header bar" when it is empty or invalid.
- Custom Number (ticked by default) writes car_num_[ID].tga: the paint carries its own number. Sim-Stamped Number writes car_[ID].tga: iRacing stamps the number on top. The two boxes switch each other off. There is no place to type a car number in Shokker.
- The Shokker choice must agree with iRacing's setting Graphics, Hide Car Numbers: ON loads car_num_[ID].tga, OFF (iRacing's default) loads car_[ID].tga. Restart iRacing after changing it, and note that iRacing updates can switch it back. With a mismatch iRacing finds no file and quietly shows the paint-shop colours. When unsure, render once in each mode: both files stay in the folder and iRacing picks the right one.
- Source Paint: the car's template. Use "Open Paint..." next to it, then "Layered template" (a PSD, XCF or ORA with the layers kept separate) or "Flat image" (an existing TGA, PNG or JPEG). RENDER shows "Set the Source Paint path in the header bar!" when nothing is open, and asks for the full path when only a file name is present.
- iRacing Car Folder: point it at the car's paint folder, not at a TGA file. The small arrow button lists the cars iRacing has made folders for, most recently painted first; the folder button browses; an empty box is filled on start with the most recently painted car. The folder must belong to the SAME car as the template and the car being driven; run the car once in iRacing first if it is not listed.
- Settings gear, "Auto-Deploy to iRacing": the checkbox "Auto-deploy after render" (off by default; an ACTIVE badge shows when on) copies renders into the car folder. It matters only when the car folder is empty, because a set iRacing Car Folder already receives every render. Simplest: set the car folder and ignore Auto-deploy.

## Where the files go
- With iRacing Car Folder set, every render copies the files into Documents\iRacing\paint\[car folder]\. The car folder name uses a space where the car path has a slash, for example "stockcars chevyss".
- Windows can have two Documents folders when OneDrive is on, so browsing by hand can show the wrong, empty one. The "Show my files" button on the Saved bar opens File Explorer on the right folder with the paint file highlighted.
- Shokker also keeps the two newest renders in its own render folder; older ones are removed automatically. With no car folder set, a render stays only there and iRacing never looks there. "Save to keep" on the render card copies a render into a subfolder so the next render does not overwrite it.
- A mistyped car folder name makes Shokker save into the folder around it and still report success, but iRacing never reads a car paint from there. Pointing at the main Documents\iRacing\paint folder (not a car's folder), at a helmet or suit folder, at a network path or drive, at a drive that is not connected, or at a folder Windows will not let Shokker write into (for example blocked by Controlled folder access) also fails.

## After the render: the Saved bar and the render card
- A toast reports "Rendered N zones in Xs" and, when saved, "Saved to N files!".
- The Saved bar at the top of the RENDER RECIPE card is one of three states. Green: "Saved!" with "Alt+Tab to iRacing and press Ctrl+R to load it on your car", the folder path, the "Show my files" button and the exact file names. Red: "Save failed" with the reason; check iRacing Car Folder. Amber: "No iRacing folder set", with "Show where it was saved".
- The card's buttons: Copy Card, Save Card PNG, Share Recipe, Copy TP Desc (the Trading Paints description text), Save to keep, Recent renders (the last 10 saved renders), and CLOSE. "Deploy to a different car" then Deploy Now copies the latest render into another car's folder.
- RENDER HISTORY (a toolbar menu) recalls one of the last 20 renders.
- If the app is not answering, the button reads "RENDER (Offline)": wait about 10 seconds, and if it stays, close and reopen Shokker Paint Booth. Terminate only stops the app waiting; the render still finishes and still copies into iRacing, so wait a minute before rendering again.
- About 20 zones that each have their own painted area is the practical limit; more can make the preview or the render fail. Undo some zones or start over.

## Loading the paint in iRacing
- After a render: Alt+Tab to iRacing, in a session with the same car, and press Ctrl+R (Reload Car Textures). The car flashes white for a moment, then shows the new files. No restart is needed.
- In a replay, move to a moment when the car is not in the pits: iRacing does not reload cars in their pit stalls.
- The 3D Car Viewer in iRacing's My Content reloads a saved paint by itself.
- Restart iRacing once after changing the Hide Car Numbers setting; it is read at start.
- The live preview in Shokker is a quick view to design with. iRacing lights the render with its own sun and shadows and adds its own number and sponsor stamps, so expect the same colours and patterns but not the same shine; shine and metal come from the spec file.

## spb_render
- It presses the same RENDER button the buyer would and waits for the result: builds the final paint and spec and saves them to the car's iRacing folder. It takes about 10-60 s.
- Call it ONCE, after the last change of a buyer request that changed the paint, not after every tool call. Never for a complaint, question or advice that changed nothing.
- With nothing changed since the last render it does nothing and says so, unless the buyer asked in words to render, save, export or send it to iRacing; then call it again with its "buyer asked to render" flag set to true.
- The result gives whether it rendered, the seconds, the zone count, how many files were saved, the iRacing folder status ("saved", "not set" or "ERROR" with the reason), whether it was pushed live, and the app's own message. Tell the buyer the seconds and the files saved.
- If the files saved is 0 or the folder is "not set", the paint was rendered but NO file was written and iRacing will not see it: say so plainly, never say it was saved, and point to the iRacing Car Folder setting or spb_check_setup.
- Errors: "A render is already running: wait for it to finish.", "The render did not start." (with the app's last messages), and a failed render with the reason.
- If an install's tool list does not include spb_render, the buyer presses RENDER (or Ctrl+R in Shokker) themselves.

## spb_check_setup
- Read-only: it changes nothing. Call it FIRST when a paint will not render, is missing in iRacing or looks different in the sim, and answer from it; do not repaint to fix a file problem.
- It reports: the iRacing User ID (digits hidden) and whether it is valid; the number mode; the car folder; the source paint and its size; whether Auto-deploy is on; template layers that are on; zone counts (total, ready, muted, with their own painted area); the RENDER button state; the preview state; the files expected and found in the car folder with their ages, including the compiled .mip; the ID the paint folders already use; and a list of findings, each marked ok, warn, bad or unknown.
- Findings it can raise: no paint file open, or only a file name; paint not square or not 2048 or 1024; ID empty, not 4-7 digits, or different from the ID in the paint folders; number mode that does not match the files found; no car folder, a network path, a file instead of a folder, a missing drive, the main paint folder, a helmet or suit folder, a typo, a folder that cannot be written, or one outside iRacing's paint folder; paint file or spec file missing or stale; compiled spec older than the newest spec; the render landed in the wrong folder; the folder holds paints for other driver IDs but none for the buyer; no car folder with Auto-deploy off; template layers on; no zones, all muted, none ready, or more than about 20 with their own painted area; an imported spec map or Spec Sculpt holding the shine; RENDER reading Offline; a failed preview.
- It ends with an iRacing-side checklist: same car, Hide Car Numbers, Ctrl+R, exact size, Trading Paints Downloader, black paint (24-bit TGA, 2048 paint textures option).

## Common file trouble and fixes
| Symptom | Cause the app knows | Fix |
| --- | --- | --- |
| Car shows paint-shop colours, no file | ID wrong or not the one the paint folders use; number mode does not match Hide Car Numbers; folder is for another car; paint not exactly 2048x2048 or 1024x1024 | spb_check_setup; fix the ID, the number mode or the folder; render; Ctrl+R |
| Nothing in the folder after RENDER | no iRacing Car Folder set, so the render stayed in Shokker's own folder | pick the car in iRacing Car Folder; render again; "Show my files" |
| Spec (chrome, metal, shine) not showing | car_spec_[ID].tga missing from the car folder, older than the last change, or compiled .mip older than it; chrome painted a normal colour instead of near-white; imported spec map or Spec Sculpt holding the shine | render with a car folder set; Ctrl+R; if the shine still looks old, move car_spec_[ID].mip out of the folder and reload |
| Old paint still showing | render landed in the wrong or a mistyped folder; Trading Paints Downloader wrote its own file over it; stale files; Ctrl+R not pressed | fix the folder; close the Downloader or turn off "Update My Own Paints" while testing a local paint; render; Ctrl+R |
| Numbers not showing or wrong | Custom Number vs Hide Car Numbers mismatch; folder holds only the other mode's file; iRacing not restarted after the setting was changed | match the two settings, restart iRacing, render, Ctrl+R |
| Number shown twice | a number-stamp layer from the template was left on | turn the template number layers off and render again |
| Wire lines or masks on the car | template guide layers baked into the render | RENDER normally leaves the guide group out; if they still show, turn the layers off and render again |
| Black paint or missing parts | paint saved as 32-bit TGA with the template alpha, or the 2048 paint textures graphics option is off | re-export as 24-bit TGA (glass cars excepted); switch the option on; restart iRacing |
| Files in the wrong car folder | folder typed with a typo, so Shokker used the folder around it | fix the last part of the name; render again; delete the stray files |
| Other drivers see the old or default car | iRacing never sends textures between drivers | upload through Trading Paints (below); also give the car a plain paint-shop colour scheme in iRacing |

## Trading Paints and other drivers
- iRacing never sends textures between drivers. Others see the paint only if they have the files in their own Documents\iRacing\paint folder, which is what the Trading Paints service does. Shokker has the Copy TP Desc button for the description text; there is no automatic upload.
- Upload the car_num_[ID].tga or car_[ID].tga that RENDER wrote as the paint (Trading Paints takes .tga or .png). Never upload the saved .spb or .shokk file: that is the Shokker project and only Shokker can open it.
- Trading Paints takes the spec only as a .mip. Leave car_spec_[ID].tga in the car folder, drive the car once in an iRacing test session, and iRacing makes car_spec_[ID].mip next to it; upload that one.
- Trading Paints calls car_[ID] paints Sim-Stamped Number paints and car_num_[ID] paints Custom Number paints; Custom Number paints need Trading Paints Pro.
- The Trading Paints Downloader writes into the same folders with the same file names. Close it, or turn off "Update My Own Paints", while testing a local paint so it cannot swap the file.
