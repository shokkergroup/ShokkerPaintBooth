# Patterns, scale and crush

## Core facts
- A paint pattern changes what the buyer sees (colour and texture across the car) and is picked in the PATTERN section of a zone, while a spec pattern changes only how the surface reflects light (metal, roughness, clearcoat) and is added under SPEC OVERLAYS with the button "＋ ADD SPEC OVERLAY".
- "Crush the pattern to 50%" and "make the camo smaller" both mean the pattern Scale: 0.50x puts twice as many repeats across the car, 1.00x is the default, the Scale slider runs 0.10x to 4.00x, and the tools accept 0.05 to 5.
- Every paint pattern has Opacity (0 to 100, default 100, 0 is invisible), Strength (default 100, 0 removes the effect), Scale, Rotate (0 to 359 degrees, default 0), and in the collapsed Advanced Pattern Control Panel Position X and Y (0 to 100, default 50) plus Flip H and Flip V.
- A zone holds up to 5 paint patterns (Pattern 1 plus 4 added layers) and up to 5 spec overlays per base layer (each new Surface library overlay starts at Strength 100 with Metallic, Roughness and Clearcoat all ticked); a pattern at Opacity 100 covers the zone colour with the pattern's own colours, while Opacity 25 to 35 keeps the zone colour and adds the texture.
- Patterns never replace the base material: the base's metal, roughness and clearcoat stay underneath, and a pattern's own spec is mixed in only through its Spec amount slider, which starts at 0%.

## Contents
1. Paint pattern versus spec pattern
2. Picking a paint pattern and the shelves
3. Scale: crush, smaller, bigger
4. Rotation, flip and position
5. Opacity, Strength and Paint mode
6. Hue, Saturation and Spec amount of a pattern
7. Stacking paint patterns
8. Spec overlays (spec patterns)
9. How a pattern meets the base material
10. Driving patterns through the tools
11. Buyer words and what they change
12. Why a change can look like nothing happened

## 1. Paint pattern versus spec pattern
- A PAINT pattern is artwork: camo blocks, carbon weave, stripes, scales, geometry. It changes the colour and light/dark texture the buyer sees on the car. It is picked inside a zone, in the BASE area, section PATTERN, row "Pattern 1 on this Layer/Zone" (hover text "Visual texture pattern that tiles across the zone"). The button "None" beside it removes the pattern.
- A SPEC pattern changes the material map only: Metallic, Roughness and Clearcoat (the app also writes them as M, R, CC). It never changes colour, so it shows as differences in shine and sparkle, in the spec preview (spb_preview with spec turned on) and in the simulator, not in the flat colour preview. It lives in the section SPEC OVERLAYS, whose header shows the base layer and a count, for example "Primary base · 2/5".
- Use a paint pattern when the buyer wants to SEE a design (camo, carbon, snake pattern, stripes). Use a spec pattern when they want the surface to feel different (finer flake, brushed grain, scales that catch the light). Many looks use both: a snake paint pattern for the colour plus a scale spec overlay for the sheen.
- Tools: spb_find_patterns searches paint patterns; spb_find_spec_patterns searches spec patterns. Each returns up to 10 results with an id, a name and a short effect text. Copy ids exactly from the result.

## 2. Picking a paint pattern and the shelves
- Click the pattern row in a zone: a full-screen picker opens. Its search box reads "Search titles, descriptions, ids, or #tags..." and the ✕ Close button closes it. The first tile is "None".
- Paint patterns are grouped on nine shelves, each shown with a small symbol in front of its name: Abstract, Fractal & Paradigm; Tech, Carbon & Industrial; Geometry, Deco & Op-Art; Nature, Animals & Weather; Cultural, World & Dark; Decades 50s-80s; 90s, Skate & Surf; Reactive & Surface Accents; Let Freedom Ring. Each shelf title shows how many patterns it holds, and there are hundreds in all. A pattern that is on no shelf does not appear in the picker.
- Real examples: Camo (digital splinter blocks, "best on matte"), Multicam (organic earth-tone blobs), Snake Skin, Snake Skin 2, Snake Skin 3 (hourglass saddle scales like rattlesnake markings), Snake Skin 4 (pebble scales) on the shelf Nature, Animals & Weather; Carbon Fiber (2x2 twill) on Tech, Carbon & Industrial; Pinstripe, Chevron on Geometry, Deco & Op-Art; Tiger Stripe and Zebra on the Nature shelf.
- Picking a pattern on a zone that has no base material puts a Gloss base under it (through the tools; in the app pick a base first, because the zone hint reads "Pick a base material + pattern, then set the color").

## 3. Scale: crush, smaller, bigger
- Pattern Scale row, label "Scale": slider 0.10x to 4.00x in 5% steps, default 1.00x, shown as "1.00x". The buttons − and + move one 5% step, ↺ resets to 1.00x. Smaller value = smaller motifs repeated more often (finer); larger value = zoomed in. Tooltip: "Pattern size — smaller values = more repetitions, larger = zoomed in".
- "Crushed to 50%" = Scale 0.50x. "Crushed to 30%" = 0.30x. "Twice as big" = 2.00x. "Bump the carbon to 150%" = 1.50x. "Crushed", "tighter", "finer" mean scale DOWN; "bigger", "blown up" mean scale UP; "crushed" is never a finish.
- The car is one 2048x2048 sheet, so a pattern that looks fine in a thumbnail is large on the car. Buyers typically ask for 30%, 40% or 50%, which is Scale 0.30x, 0.40x or 0.50x.
- Base Scale (BASE section, label "Base Scale") is a different control: it sizes the base material's own texture (metal flake, grain), range 0.05x to 5.0x, centre 1.00x, tooltip "Scale the base material texture". "Make the flake finer" on a flake finish means Base Scale down, not the pattern Scale.
- The slider limits differ from the tools. The app's pattern Scale stops at 0.10x to 4.00x; the tools accept 0.05 to 5, so a tool can set a value the slider cannot reach. Say the number you set.

## 4. Rotation, flip and position
- Row "Rotate": slider 0 to 359 degrees in 1 degree steps, a number box, − and + for 1 degree, ↺ to reset. Default 0.
- "Rotate the stripes 45" = Rotate 45. Pinstripe, Chevron, Tiger Stripe and Zebra are stripe patterns; rotate the zone that holds the pattern.
- Advanced Pattern Control Panel (collapsed, click its header): "Position X" and "Position Y", 0 to 100 percent (slider steps of 5%, the − and + buttons move 1%), default 50% (centre); "Flip H" and "Flip V" check boxes ("Mirror the pattern horizontally / vertically"); and a "Strength Map OFF/ON" button ("Paint where the pattern is strong vs weak").
- Pattern placement buttons: "Full Canvas" (the default tiling plus the X/Y numbers), "Fit to Zone" (fits the pattern into the zone's bounds; the position sliders lock while it is on) and "Edit on Template" (drag the pattern directly on the car sheet).
- The tools set a pattern's scale and rotation but have no field for position or flip. When the buyer wants the pattern moved or mirrored, tell them to use Position X / Position Y or Flip H / Flip V in the zone panel.

## 5. Opacity, Strength and Paint mode
- "Paint mode" drop-down: "Overlay — full pattern" (the pattern's own colours cover the paint) or "Blend — keep paint color" (the pattern only shades the zone colour). Applies to all pattern layers of the zone. Default is Overlay.
- "Opacity": 0 to 100 percent, 5% steps, default 100. 0 = invisible, 100 = full. Opacity is how much of the pattern shows over the paint.
- "Strength": slider 0 to 100 percent, default 100, tooltip "Pattern effect in paint and spec — 0% removes the effect; 100% applies full strength". The + button can push it past 100, up to 200.
- Rule of thumb: at Opacity 100 the pattern's own colours take over (camo is earth-tone, so hot pink + Camo at 70 reads brown); at 25 to 35 the zone colour stays and the pattern adds texture. For "pink camo", keep Opacity near 30 or use Blend.
- To keep the buyer's colour and add only texture, choose Blend or lower Opacity. To get the pattern's own colours (real camo greens), use Overlay at Opacity 100.

## 6. Hue, Saturation and Spec amount of a pattern
- Three more sliders sit under Strength, once per pattern layer: "Hue" (−180 to 180 degrees, step 1, default 0), "Saturation" (−100 to 100 percent, step 5, default 0; −100 is grayscale) and "Spec amount" (0 to 100 percent, step 5, default 0). Each has ↺ to reset to 0.
- Hue and Saturation recolour only the pattern artwork and apply in Overlay mode; in Blend mode they are greyed out because Blend keeps the paint colour.
- Spec amount starts at 0% so the pattern leaves the base material alone. Raising it reveals the pattern's own metallic, roughness and clearcoat: 50% mixes the pattern's spec and the base's equally, 100% replaces them inside the zone.
- Spec amount uses the same Scale, Rotate and placement as the pattern, and is independent of Opacity and Strength: a pattern can be invisible in colour (Opacity 0) and still carry its spec.

## 7. Stacking paint patterns
- Under the pattern row, the button "+ Add Layer" adds another pattern to the same zone (Pattern 2, 3, 4, 5). The limit is 5 patterns in all; at the limit the app says "Max 5 patterns (Pattern 1 + 4 layers)".
- Each added layer has its own picker, a "None" button that removes the layer, Hue, Saturation, Spec amount, Opacity (0 to 100), Scale (0.10x to 4.00x), Rotate (0 to 359) and a "Blend" drop-down with Normal, Multiply, Screen and Overlay.
- A possible stack: Camo as Pattern 1 at Scale 1.00x and Carbon Fiber as Pattern 2 at Scale 0.30x with Blend Multiply. The tools set only Pattern 1; extra layers are set in the zone panel.

## 8. Spec overlays (spec patterns)
- Section SPEC OVERLAYS (header example: "Primary base · 2/5"), text "Material detail on your existing paint. Layers apply from top to bottom." Add with "＋ ADD SPEC OVERLAY" (disabled at 5; the app says "Maximum 5 spec overlays per base"). The picker has two collections: "Surface library" with ten families (Machined & Brushed, Weave & Composite, Crystal & Mineral, Skin & Cellular, Liquid & Coating, Crack & Weather, Optical & Interference, Engraved & Ornamental, Track & Motorsport, Experimental Structures) and a "Legacy collection" with older shelves such as Predator Skins and Organic & Natural.
- Each overlay layer has: the pattern button, × to remove, ↑ and ↓ to reorder, "Duplicate", "Mute"/"Unmute", "Solo", "Inspect"; then "Strength" (0 to 100; overlays from the Surface library start at 100, Legacy collection overlays at 50); three check boxes "Metallic", "Roughness", "Clearcoat" (all on by default, untick one to leave that channel alone); "Size" (25% to 100%, step 5, default 100%; "Smaller size = finer detail, repeated across the surface"); "Rotation" (0 to 359); "X position" and "Y position" (0 to 100%, default 50%); "Coverage box" (1 to 100%, default 100%); "Variation" (a number that changes the random layout, Surface library only). Legacy patterns also show "Legacy range" (0 to 100, default 40) and a "Blend" drop-down (normal, multiply, screen, overlay, hardlight, softlight).
- Stacking: layers apply from top to bottom, and saved legacy layers apply before the Surface library layers. Example for a rattlesnake: Snake Scale Diamond (Legacy collection, shelf Predator Skins) at Strength 60, or Snake Scales (shelf Organic & Natural).
- Through the tools the spec patterns of a zone are one list of up to 5 entries with id, opacity 0 to 100, scale 0.05 to 5, rotation 0 to 359 and channels as the letters M, R, C. Sending the list REPLACES the zone's existing spec patterns, so always send the complete list the buyer should end with.
- Each tool entry's scale means the overlay's Size, but the app's Size slider only goes 25% to 100%. Prefer scale between 0.25 and 1 so what you report matches the panel.

## 9. How a pattern meets the base material
- The zone's BASE (a finish such as Gloss, Matte, Chrome, Metal Flake) sets the underlying spec. spb_finish_details gives any base's exact metal, roughness and clearcoat. A paint pattern is drawn on top of this base and leaves its metal/roughness/clearcoat in place unless Spec amount is raised.
- "Base Strength" (0 to 100, default 100): how much of the base shows over the source paint; 0 = the original paint. "Spec Strength" (0 to 100, default 100): "Weakens this base's MATERIAL itself" (metallic, roughness and clearcoat shift toward neutral). Both are in the BASE section; they act on the base, not on the pattern.
- "Spec Blend" (BASE section, drop-down): how a pattern reshapes the base's optics. Normal, plus Ghost Carve, Chrome Inlay, Frost Etch, Angle Flip, Ember Gate, Depth Press, and legacy Multiply, Screen, Overlay, Hard Light, Soft Light. Leave it on Normal unless the buyer asks for those effects.
- Pattern Opacity 0 or Strength 0 gives you the plain base again.
- Base Rotation (0 to 355, step 5) and Base Scale turn and size the base texture; pattern Rotate and Scale turn and size the pattern. They are separate rows.

## 10. Driving patterns through the tools
- Find first: spb_find_patterns "camo" returns ids; spb_find_spec_patterns "snake scales" returns spec ids. Use the exact id.
- Set: spb_edit_zone (or spb_add_zone for a new part) with a pattern object holding id, opacity 0 to 100, scale 0.05 to 5 and rotation 0 to 359, and, for spec, the spec patterns list. Setting the pattern id to "none" removes it. Scale and rotation on the zone itself (outside the pattern object) mean the BASE texture size and rotation.
- Iterate with spb_tweak on the working zone: change = scale (direction down = smaller/finer); the zone's pattern is scaled when it has one, else the base texture. One "smaller" step shrinks the pattern clearly (to roughly 60% of its size); "a bit" and "a lot" give smaller and bigger steps. The result stays between 0.05 and 5.
- spb_tweak rotation: adds or subtracts degrees on the pattern (or the base when there is no pattern); default 30, "a bit" 15, "a lot" 90, or the exact number the buyer said. spb_tweak opacity: pattern Opacity moves by 25 points ("a bit" 15, "a lot" 40), kept between 5 and 100; with no pattern it moves the finish intensity instead.
- Never rebuild a pattern from scratch for "smaller" or "rotate it". For exact numbers ("crushed to 40%") use spb_edit_zone with scale 0.4 in the pattern object.
- Finish with spb_preview (turn the spec view on to check spec patterns) and one spb_render at the end of the request.

## 11. Buyer words and what they change
- "Make the camo smaller" / "tighter" / "finer": pattern Scale down, spb_tweak scale down. "Crush it to 50%": Scale 0.50x.
- "Make the camo bigger" / "blow it up": Scale up. "Twice as big": Scale 2.00x.
- "Rotate the stripes 45": Rotate 45 degrees (spb_tweak rotation with amount 45). "Turn it a bit": 15 degrees.
- "Make the flake finer": Base Scale down on the flake finish (spb_tweak scale down when the zone has no paint pattern; if it has one, send scale in spb_edit_zone instead, because the tweak would resize the pattern). For a spec flake pattern, lower the overlay's Size.
- "Make the camo subtler" / "less intense": pattern Opacity down (spb_tweak opacity down), or Strength down. As a follow-up on a pattern you just placed, "stronger" or "more visible": Opacity up. (A bare "make it pop" with nothing just changed is a vague request: offer options first.)
- "Keep my pink, just add texture": Blend mode, or Opacity 25 to 35.
- "Give it a snake skin feel, not a snake print": spec pattern Snake Scale Diamond; "show the scales": paint pattern Snake Skin 3.
- "Mirror it" / "move it left": panel only (Flip H, Position X); the tools cannot do these.
- "Make it shinier": not a pattern control; use spb_tweak shine.

## 12. Why a change can look like nothing happened
- A pattern with Opacity 0 or Strength 0 is invisible; check both.
- A spec pattern does not change colour; compare in the spec preview or the simulator before saying it failed.
- Very small scale on a spec overlay can be too fine to see in a preview; say it is applied and may show only in the simulator.
- A zone covered by zones above it shows 0 percent: edit or reorder the zone that really shows (spb_get_zones lists the visible share).
- Hue and Saturation sliders do nothing in Blend mode.
