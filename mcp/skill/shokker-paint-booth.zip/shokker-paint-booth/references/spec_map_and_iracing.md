# Spec map and iRacing

## Core facts
- iRacing reads every metal, chrome and shine effect from one spec file, car_spec_[ID].tga: red is metallic (0 = not metal, 255 = full metal), green is roughness (0 = mirror smooth, 255 = fully matte), blue is clearcoat (0-15 = none, 16 = maximum gloss, rising to 255 = dull) and alpha is a specular mask.
- Shokker Paint Booth writes M / R / CC / A in its number readouts, so "R" there means ROUGHNESS (the green channel), while its channel buttons name the colour first (R Metal, G Rough, B Coat, A Mask).
- A paint colour alone never looks metallic in the sim; full metal over a dark paint colour renders nearly black because iRacing multiplies the paint by the metal, so silver chrome needs a white or near-white paint underneath.
- The live preview shows colour and pattern but not true sim shine, so judge shine in the spec view or the Shine bar, then in iRacing after Ctrl+R.
- Fine spec detail shrinks with distance: iRacing mip-maps its textures, so single-pixel spec noise and very fine flake average out to a flat tone unless the detail is drawn large enough.

## Contents
- The four channels
- Where Shokker shows the channels
- Reading the spec view colours
- Sheen ladder with real values
- Metal, chrome, brushed and carbon
- What each channel does in the sim
- Distance, mips and what to suggest
- Why it looks different in iRacing
- The compiled spec (.mip) and Trading Paints
- Tools that read or check the spec

## The four channels
| Channel | Colour in the file | Range and meaning | Shokker labels |
| --- | --- | --- | --- |
| Metallic | red | 0 = not metal, 255 = full metal | M in readouts; R Metal / R Metallic on channel buttons |
| Roughness | green | 0 = mirror smooth, 255 = fully matte | R in M / R / CC readouts; G Rough / G Roughness on buttons |
| Clearcoat | blue | 0-15 = no clearcoat, 16 = maximum gloss, 255 = dull | CC in readouts; B Coat / B Clearcoat on buttons |
| Specular mask | alpha | the inspector calls it rarely used, an advanced control: normal, half, or no sun and environment light per spot (Lighting Mask presets below) | A in readouts; A Mask on buttons |

- Blue runs backwards: a higher blue is a duller coat, not more clearcoat.
- In SPB a clearcoat of exactly 0 means no clearcoat, and the app treats 1-15 as the maximum-gloss 16 when it writes the file. Blue 0-15 all mean "no clearcoat" to iRacing, not a thin coat: that area renders bare and flat next to a glossy body, and Spec Doctor flags it as "Clearcoat Set To N (Means No Coat)". When a buyer's own imported spec file holds blue 1-15, Spec Doctor warns that Shokker exports 1-15 as full gloss.
- Finish descriptions list the first three channels as (M/R/CC): Gloss is "(0/30/16)".
- Finish changes only how the paint looks, never how the car drives.

## Where Shokker shows the channels
- Live Preview: turn on the SPLIT view and the SPEC MAP pane appears beside PAINT. Its filter buttons are ALL, R Metal, G Rough, B Coat, A Mask, and the pane label follows the channel: SPEC MAP, METALLIC (R), ROUGHNESS (G), CLEARCOAT (B), SPEC MASK (A).
- Chips above the live preview read COMBINED, R METAL, G ROUGH, B COAT (they appear once a spec preview exists); hover one to enlarge it, click for the full view.
- The Channels button (title "Channels Inspector") beside Refresh on the rendered view opens "Spec Map - Channels & Values": buttons ALL, R Metallic, G Roughness, B Clearcoat, A Mask, a min / max / mean table (R (Metallic), G (Roughness), B (Clearcoat), A (Spec mask)) and a click-to-read "Sampled Material" line showing M, R, CC and A. Sample area is Point (exact pixel), 3x3 Median or 5x5 Median.
- The Spec Tools menu holds Decal Rescue Kit..., Lighting Mask..., Material Sampler... (the same inspector) and Range Remapper... (Low and High 0-255 for Metallic, Roughness and Clearcoat, with Restore Original).
- The Shine bar on the Live Preview has Off, Lens, Full and Sweep. It is a view only: it never renders or writes files. Holding the ` key over the car peeks the shine with any tool.
- The Material menu holds Material Brush, Spec Brush (metallic / roughness / clearcoat only, paint stays), Wear Brush, Spec Eyedropper, Flake Studio..., Spec Doctor and Auto Spec....

## Reading the spec view colours
- The combined spec view is colour-coded: red = metal, teal = matte, black = gloss. Black means all channels are low: a smooth, non-metal, glossy surface (blue 16 is the MAXIMUM gloss), not "no clearcoat" and not flat.
- Where no zone claims a pixel (for example with the catch-all muted), the spec is a plain gloss: metallic 5, roughness 100, clearcoat 16, mask 255.
- A mostly red area is metal, a mostly teal area is matte, and a mostly black area is smooth gloss.
- spb_preview with its spec option on adds the spec map to the preview; use it before telling a buyer what the shine will do.

## Sheen ladder with real values
Foundation shelf, flat bases that keep the buyer's own paint colour. Values are M / R / CC.

| Finish | M | R | CC | In buyer words |
| --- | --- | --- | --- | --- |
| Wet Look | 0 | 15 | 16 | razor-wet lacquer: the tightest highlight a dielectric paint can have, concours depth |
| Gloss | 0 | 30 | 16 | standard glossy body; the safe default under sponsors and numbers |
| Semi-Gloss | 0 | 55 | 40 | everyday enamel; broader, calmer highlight than gloss |
| Satin | 0 | 95 | 70 | satin body film: soft sheen, no hard reflections; silk and vinyl-wrap sheens live here |
| Eggshell | 0 | 140 | 100 | soft diffuse; the last stop before matte |
| Matte | 0 | 200 | 160 | light is absorbed, a faint coat keeps it from going dead |
| Primer | 0 | 215 | 200 | duller than matte, almost no coat; project-car honesty |
| Flat Black | 0 | 250 | 255 | dead flat, zero coat |
| Powder Coat | 10 | 120 | 145 | eggshell sheen with the clearcoat suppressed; industrial |
| Pearl | 100 | 40 | 16 | half-metal response with a polished highlight, your colour in pearl light |
| Satin Pearl | 100 | 90 | 60 | pearl with the highlight softened |
| Metallic | 200 | 50 | 16 | general body metallic: flat metallic material, no baked-in flake |
| Candy | 200 | 15 | 16 | polished metallic under a colour you pick; deep hot-rod glass without a clear layer |
| Brushed | 180 | 75 | 65 | broad metal highlight with a weak coat; add a brushed-grain Spec Pattern Overlay for visible grain |
| Frozen | 160 | 85 | 130 | hazed metallic with the coat pushed back; cold and dry |
| Matte Metallic | 225 | 140 | 100 | rough hazed metal that does not shine |
| Bead Blast | 180 | 160 | 140 | broad diffuse sparkle, no coat |
| Chrome | 255 | 2 | 16 | mirror chrome: full metal, no roughness; near-white colour for silver, any colour for tinted chrome |
| Dark Chrome | 250 | 15 | 40 | chrome-tier response with a weaker coat; pick a dark colour for gunmetal or black chrome |
| Satin Chrome | 250 | 45 | 40 | chrome-tier metal with a broader, softer highlight |

- Carbon is a pattern, not a flat base: pick Carbon Fiber (shelf Tech, Carbon & Industrial; a classic 2x2 twill carbon weave, the number-one pattern, works on any base, sponsor-safe). Choose the sheen from the ladder above and lay the pattern on it.
- Any pattern, flake or spec overlay on top moves these numbers; spb_finish_details gives the measured metal, roughness and clearcoat of one finish.

## Metal, chrome, brushed and carbon
- Chrome: use Chrome and paint the part white or near-white for silver; any other colour gives a darker tinted chrome. Dark Chrome with a dark colour gives gunmetal or black chrome.
- Dark or overcast tracks give metal little to reflect, so flat chrome can read as grey paint there.
- Chrome on near-black paint with no clearcoat reflects almost nothing and shows up as a black hole on track (Spec Doctor: "Chrome Over Near-Black Paint").
- Brushed metal: Brushed (180/75/65) with a brushed-grain Spec Pattern Overlay for visible grain, or Wire Brushed on the Foundation EFX shelf (swirl scratches, bright on the crests).
- Mirror-smooth paint that is not metal: Wet Look (0/15/16), the tightest highlight a dielectric paint can have.
- Carbon: the Carbon Fiber pattern works on any base, so pick the base from the ladder (Gloss, Satin, Matte...).
- Metal that does not shine: Matte Metallic (225/140/100) or Frozen.

## What each channel does in the sim
- Metallic (red): 0 = dielectric paint, 255 = full metal; iRacing multiplies the paint colour by the metal, so a normal colour turned metallic goes dark and chrome needs white underneath.
- Roughness (green): 0 = mirror smooth, 255 = fully matte.
- Clearcoat (blue): 16 is maximum gloss, larger values are duller, 0-15 all mean no clearcoat.
- Alpha (Lighting Mask presets): Full Lighting = 255, Reduced Lighting = 128 for recessed vents and deep seams, Kill Lighting = 0 for fake holes, grille openings and geometry that should look unlit. Kill Lighting is not a shortcut for matte vinyl. Use Source Alpha removes the override.
- Numbers and sponsors that iRacing stamps sit on whatever spec is under them. Decal Rescue Kit presets (M / R / CC): Flat Vinyl 0/100/110, Satin Decal 0/100/75, Gloss Decal 0/42/22.

## Distance, mips and what to suggest
- iRacing builds smaller copies of each texture for distance (mip levels); in Flake Studio each distance step is one iRacing mip level, a 2x2 box filter.
- Flake Studio (Material menu) sizes flake in real centimetres (slider 0.05 to 3 cm). Its Distance slider steps Up Close, Mip 1, Mip 2, Mip 3, Across Track and a meter shows how much flake signal is left. At Mip 2 the status reads either "reads as flake" or "goes flat grey", and very large flake is flagged as glitter.
- Sim-Safe in Flake Studio adds a coarse flake band so the flake still reads at Mip 2. Starting looks: Fine Silver 0.25 cm, Bass-Boat 1.2 cm, Candy Over Flake 0.6 cm, White Pearl 0.4 cm, Colour-Shift Pearl 0.5 cm, Satin Metallic 0.3 cm.
- Spec Doctor flags "Pixel Noise In Roughness Will Shimmer": single-pixel spec noise sparkles up close, averages away at distance and flickers as the car moves.
- Suggest: bigger flake or a stronger sparkle (Flake Studio's own advice when Sim-Safe cannot fit); flat finishes cut glare so numbers and sponsor text stay readable at distance, and shinier ones show more colour depth up close; many racers go satin or gloss on the body and keep numbers plain.
- Seams at panel edges come from the sim filtering the sheet. The Settings option "Bleed Paint Past Panel Edges" copies each panel's edge paint and spec a few pixels into the gaps ("Fixes seams in iRacing"). It needs the car's Wire template layer.
- In Flake Studio the Base Rough and Flake Rough sliders start at 15 and the Clearcoat slider starts at 16 (it never offers clearcoat 1-15).

## Why it looks different in iRacing
| What the buyer sees | Cause the app knows | Fix |
| --- | --- | --- |
| Chrome or metal looks dark or flat | paint not near-white; metal not ~255 or roughness not near 0; blue 255 dulls it | white underneath; check the spec view; Ctrl+R in iRacing |
| No shine at all | car_spec_[ID].tga missing from the car folder, or older than the last change | RENDER again with a car folder set; spb_check_setup |
| Old shine after a new render | the compiled car_spec_[ID].mip is older than the newest spec .tga | Ctrl+R; if still old, move the .mip out of the folder and reload |
| Wire lines, mask shapes or number blocks on the car | template guide layers left on | RENDER normally leaves the guide group out by itself and says so on the Saved bar; if they still show, turn those layers off and render again |
| The number shows twice | a number-stamp layer from the template was left on | turn the template number layers off and render again |
| Numbers or sponsors look chrome or dull | stamps inherit the body's spec | Decal Rescue Kit; Spec Doctor "Took The Body's Chrome" |
| Black paint or missing parts | TGA saved 32-bit with the template alpha, or the 2048 paint textures option off | 24-bit TGA; switch the option on; restart iRacing |
| A rim of the wrong finish on edges (shiny halo on matte, dull on gloss) | Spec Doctor finding "Spec Sits N px Off The Paint" | Spec Doctor fixes: Snap The Zone Mask Back Into Line, or Re-Align The Spec Here |
| Whole car shines the same | "One Material On The Whole Car" | give stripes, numbers and body different finishes |
| Preview does not match | preview is not the sim's lighting | judge in iRacing after Ctrl+R |

## The compiled spec (.mip) and Trading Paints
- iRacing compiles the spec into car_spec_[ID].mip next to the .tga the first time it loads it. For the buyer's own car it reads the .tga when it is newer than the .mip and rebuilds the .mip; Ctrl+R in iRacing is enough after a render.
- Trading Paints takes the spec only as car_spec_[ID].mip. Leave the .tga in the car folder, drive the car once, and upload the .mip iRacing made. Other drivers see the buyer's paint only if they have the files.
- The Trading Paints Downloader writes into the same folders with the same names; close it while testing a local paint.

## Tools that read or check the spec
- spb_preview (spec on), spb_finish_details, spb_find_spec_patterns (flake, sparkle, brushed, holographic prism, weave, weathering).
- spb_check_setup reads the files in the car folder, including the spec and compiled .mip ages.
- spb_kit with its spec kit (when the tool list includes it): check = Spec Doctor report (read-only, renders the spec map once, 20-120 s); propose = Spec Autopilot proposal, one material per layer (read-only, assigns nothing); fix applies ONE Doctor fix the buyer asked for; apply gives the proposed materials to the layers, only after the buyer saw the proposal and agreed, and changes spec only, never artwork, zones or colours.
- Spec questions and complaints get an answer first; change nothing until the buyer picks a fix.
